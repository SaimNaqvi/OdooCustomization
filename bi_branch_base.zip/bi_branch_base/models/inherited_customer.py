# Part of BrowseInfo. See LICENSE file for full copyright and licensing details.

from odoo import api, fields, models, _


class ResPartnerIn(models.Model):
    _inherit = 'res.partner'

    user_in_branch = fields.Boolean(compute='_compute_user_in_branch')

    @api.model
    def default_get(self, default_fields):
        res = super(ResPartnerIn, self).default_get(default_fields)
        if self.env.user.branch_id:
            res.update({
                'branch_id': self.env.user.branch_id.id or False
            })
        return res

    @api.depends('branch_id')
    def _compute_user_in_branch(self):
        user_branch_ids = self.env.user.branch_ids.ids
        for record in self:
            record.user_in_branch = bool(set(record.branch_ids.ids) & set(user_branch_ids))
    branch_id = fields.Many2one('res.branch', string="Branch")
