from odoo import api, fields, models, _
from odoo.exceptions import UserError


class InheritedSaleSubscription(models.Model):
    _inherit = 'sale.subscription'

    @api.onchange('partner_id')
    def _onchange_partner_id(self):
        for record in self:
            if record.partner_id:
                record.branch_id = record.partner_id.branch_id.id

    @api.depends('partner_id')
    def _compute_branch_id(self):
        for record in self:
            record.branch_id = record.partner_id.branch_id.id if record.partner_id else False

    branch_id = fields.Many2one('res.branch', string="Branch")


class SubscriptionTemplate(models.Model):
    _inherit = 'sale.subscription.template'

    branch_id = fields.Many2one('res.branch', string='Branch')
