# -*- coding: utf-8 -*-
# Part of BrowseInfo. See LICENSE file for full copyright and licensing details.
{
    'name': 'Multi Branch Base',
    'version': '15.0.0.2',
    'category': 'Sales',
    'summary': 'Multiple Branch Base Multi Branch base Multiple Unit multiple Operating unit sales branch Multi Branches multi company multi branch multi company multiple unit operation multi unit multiple operation multi operation invoice multi branch unit base odoo',
    "description": """
       
       Base Multi Branch in Odoo,
       Base Branch in odoo,
       manage branch master in odoo,
       Set Branch on Contacts in odoo,
       Multi Branch Concept in odoo,
       multiple Branch for customer in odoo,
       multiple Branch for user in odoo,
       multiple Branch for contact in odoo,
    
    """,
    'author': 'BrowseInfo',
    "price": 10,
    "currency": 'EUR',
    'website': 'https://www.browseinfo.com',
    'depends': ['web', 'base',
                'sale_management',
                'purchase',
                'stock',
                'account',
                'purchase_stock',
                'point_of_sale',
                'pos_sale',
                # 'sale_stock',
                'account_asset'
                ],
    'data': [
        'security/branch_security.xml',
        'security/multi_branch.xml',
        'security/ir.model.access.csv',
        'views/res_branch_view.xml',
        'views/inherited_res_users.xml',
        'views/inherited_partner.xml',
        'views/inherited_sale_order.xml',
        'views/inherited_stock_picking.xml',
        'views/inherited_stock_move.xml',
        'views/inherited_account_invoice.xml',
        'views/inherited_purchase_order.xml',
        'views/inherited_stock_warehouse.xml',
        'views/inherited_stock_location.xml',
        'views/inherited_account_bank_statement.xml',
        'views/inherited_sale_subscription.xml',
        'wizard/inherited_account_payment.xml',
        # 'views/inherited_stock_inventory.xml',
        'views/inherited_product.xml',
        'views/inherited_partner.xml',
        'views/inherited_pos_config.xml',
        # 'views/assets.xml',
        'views/company.xml',
    ],
    'assets': {
        'web.assets_qweb': [
            'bi_branch_base/static/src/xml/branch.xml'
        ],
        'web.assets_backend': [
            'bi_branch_base/static/src/js/branch_service.js',
            'bi_branch_base/static/src/js/session.js',
        ]
    },
    'license': 'OPL-1',
    'installable': True,
    'auto_install': False,
    'live_test_url': 'https://youtu.be/T6MMTsIQjto',
    "images": ['static/description/Banner.png'],
    'post_init_hook': 'post_init_hook',
}
