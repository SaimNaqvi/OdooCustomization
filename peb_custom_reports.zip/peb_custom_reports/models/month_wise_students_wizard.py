from odoo import models, fields, api ,_
from datetime import datetime

class MonthWiseStudentsWizard(models.TransientModel):
    _name = 'month.wise.students.wizard'
    _description = 'Month Wise Students Report Wizard'

    month = fields.Selection([
        ('01', 'January'), ('02', 'February'), ('03', 'March'),
        ('04', 'April'), ('05', 'May'), ('06', 'June'),
        ('07', 'July'), ('08', 'August'), ('09', 'September'),
        ('10', 'October'), ('11', 'November'), ('12', 'December')
    ], string="Month", required=True)

    year = fields.Integer(string="Year", default=lambda self: datetime.now().year)

    def generate_month_wise_report(self):
        # This method will trigger the report generation
        self.ensure_one()
        data = {
            'month': self.month,
            'year': self.year,
        }
        return {
            'type': 'ir.actions.report',
            'report_name': 'peb_custom_reports.report_month_wise_students_xlsx',
            'report_type': 'xlsx',
            'data': data,
        }
