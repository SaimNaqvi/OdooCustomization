from odoo import models, fields, api, _
from datetime import datetime, timedelta


class FeeDefaulterWizard(models.TransientModel):
    _name = 'fee.defaulter.wizard'
    _description = 'Fee Defaulter Wizard'

    admission_year = fields.Selection(
        [(str(year), str(year)) for year in range(2000, datetime.today().year + 1)],
        string="Admission Year"
    )

    branch = fields.Many2one('res.branch', string="Branch")
    student_id = fields.Many2one('res.partner', string="Student ID", ondelete='set null')
    student_name = fields.Many2one('res.partner', string='Student Name')

    start_date = fields.Date(string="Start Date")
    end_date = fields.Date(string="End Date")
    till_date = fields.Date(string="Till Date")

    MONTH_SELECTION = [
        ('January', 'January'), ('February', 'February'), ('March', 'March'), ('April', 'April'),
        ('May', 'May'), ('June', 'June'), ('July', 'July'), ('August', 'August'),
        ('September', 'September'), ('October', 'October'), ('November', 'November'), ('December', 'December')
    ]

    start_month = fields.Selection(MONTH_SELECTION, string="Start Month")
    end_month = fields.Selection(MONTH_SELECTION, string="End Month")

    start_year = fields.Selection([(str(year), str(year)) for year in range(datetime.today().year, 1999, -1)],
                                  string="Start Year")
    end_year = fields.Selection([(str(year), str(year)) for year in range(datetime.today().year, 1999, -1)],
                                string="End Year")

    day = fields.Boolean(string='Day')
    period_week = fields.Boolean(string='Week')
    period_month = fields.Boolean(string='Month')
    period_year = fields.Boolean(string='Year')

    religion = fields.Selection(
        [('Islam', 'Muslim'), ('Hindu', 'Hinduism'), ('Sikh', 'Sikh'), ('Christian', 'Christianity')],
        string='Religion')
    gender = fields.Selection([('male', 'Male'), ('female', 'Female')], string='Gender')
    adopted = fields.Boolean(string='Adopted')
    active = fields.Boolean(string='Active')
    employees = fields.Boolean(string='Employees')
    classes = fields.Many2many('school.class', string='Classes')

    concessions = fields.Selection(
        [('100', '100%'), ('75', '75%'), ('50', '50%'),
         ('25', '25%'), ('0', '0%')],
        string="Concessions")

    @api.onchange('concessions')
    def _onchange_concessions(self):
        if self.concessions:
            concessions = int(self.concessions)  # Convert string to integer
            # print(f"Concessions selected: {concessions}")  # Debug output

            # Get all partner_ids with the selected concession_percent
            partner_ids = self.env['account.move'].search([
                ('concession_percent', '=', concessions)
            ]).mapped('partner_id.id')  # Get related student IDs

            # print(f"Partner IDs found: {partner_ids}")  # Debug output

            # if not partner_ids:
            #     print("No students found for concession value:", concessions)  # Debug message

            return {'domain': {'student_id': [('id', 'in', partner_ids)]}}  # Apply domain filter
        else:
            # print("No concession selected")  # Debug output
            return {'domain': {'student_id': []}}

    @api.onchange('day', 'period_week', 'period_month', 'period_year')
    def _onchange_period(self):
        today = datetime.today().date()

        if self.day:
            self.start_date = self.end_date = today
        elif self.period_week:
            start_of_week = today - timedelta(days=today.weekday())  # Start of this week (Monday)
            end_of_week = start_of_week + timedelta(days=6)  # End of this week (Sunday)
            self.start_date = start_of_week
            self.end_date = end_of_week
        elif self.period_month:
            start_of_month = today.replace(day=1)  # Start of the current month
            if today.month == 12:
                end_of_month = today.replace(year=today.year + 1, month=1, day=1) - timedelta(days=1)
            else:
                end_of_month = today.replace(month=today.month + 1, day=1) - timedelta(days=1)
            self.start_date = start_of_month
            self.end_date = end_of_month
        elif self.period_year:
            start_of_year = today.replace(month=1, day=1)  # Start of this year
            end_of_year = today.replace(month=12, day=31)  # End of this year
            self.start_date = start_of_year
            self.end_date = end_of_year
        else:
            # If no period is selected, reset dates
            self.start_date = False
            self.end_date = False

    @api.onchange('start_date', 'end_date')
    def _onchange_dates(self):
        """ Update start_month and end_month when dates are changed """
        MONTH_MAPPING = {
            1: 'January', 2: 'February', 3: 'March', 4: 'April',
            5: 'May', 6: 'June', 7: 'July', 8: 'August',
            9: 'September', 10: 'October', 11: 'November', 12: 'December'
        }
        if self.start_date:
            self.start_month = MONTH_MAPPING.get(self.start_date.month)
        if self.end_date:
            self.end_month = MONTH_MAPPING.get(self.end_date.month)

    @api.onchange('start_month')
    def _onchange_start_month(self):
        """ Update start_date based on selected start_year and start_month """
        MONTH_MAPPING = {
            'January': 1, 'February': 2, 'March': 3, 'April': 4,
            'May': 5, 'June': 6, 'July': 7, 'August': 8,
            'September': 9, 'October': 10, 'November': 11, 'December': 12
        }

        if self.start_year and self.start_month:
            try:
                start_month_num = MONTH_MAPPING.get(self.start_month)
                self.start_date = datetime(int(self.start_year), start_month_num, 1).date()
            except (ValueError, TypeError):
                self.start_date = None

    @api.constrains('adopted', 'active', 'employees')
    def _check_status_only_one_selected(self):
        # Ensure only one of 'adopted', 'active', or 'employees' is selected
        status_count = sum([self.adopted, self.active, self.employees])
        if status_count > 1:
            raise ValidationError("You can only select one status: Adopted, Active, or Employees.")

    @api.onchange('end_month', 'end_year')
    def _onchange_end_month(self):
        """ Update end_date based on selected end_year and end_month """
        MONTH_MAPPING = {
            'January': 1, 'February': 2, 'March': 3, 'April': 4,
            'May': 5, 'June': 6, 'July': 7, 'August': 8,
            'September': 9, 'October': 10, 'November': 11, 'December': 12
        }

        if self.end_year and self.end_month:
            try:
                end_month_num = MONTH_MAPPING.get(self.end_month)
                # Get last day of the selected month
                last_day = (datetime(int(self.end_year), end_month_num, 1) + timedelta(days=32)).replace(
                    day=1) - timedelta(days=1)
                self.end_date = last_day.date()
            except (ValueError, TypeError):
                self.end_date = None

    @api.onchange('start_year', 'end_year')
    def _onchange_years(self):
        if self.start_year and self.end_year:
            self.start_date = f"{self.start_year}-01-01"
            self.end_date = f"{self.end_year}-12-31"

    def reset_form(self):
        self.start_year = None
        self.end_year = None
        self.start_date = None
        self.end_date = None
        self.religion = ""
        self.student_id = None
        self.adopted = False
        self.active = False
        self.employees = False
        self.classes = []  # Reset to an empty list
        self.student_name = None
        self.start_month = ""
        self.end_month = ""
        self.concessions = ""
        self.branch = []

        return {
            'name': _('Fee Defaulter Report'),
            'type': 'ir.actions.act_window',
            'res_model': 'fee.defaulter.wizard',
            'view_mode': 'form',
            'view_id': self.env.ref('peb_custom_reports.view_fee_defaulter_wizard_form').id,
            'target': 'new',
        }

    def generate_report_fee_defaulter(self):
        start_date, end_date = self.get_period_dates()

        data = {
            'start_date': start_date,
            'end_date': end_date,
            'branch_id': self.branch.ids if self.branch.ids else None,
            'student_id': self.student_id.id if self.student_id else None,
            'religion': self.religion,
            'gender': self.gender,
            'concessions': self.concessions,
            'active': self.active,
            'adopted': self.adopted,
        }

        return {
            'type': 'ir.actions.report',
            'report_name': 'peb_custom_reports.fee_defaulter_xlsx',
            'report_type': 'xlsx',
            'data': data
        }

    def get_period_dates(self):
        return self.start_date, self.end_date

    def print_fee_defaulter_pdf(self):
        return self.env.ref('peb_custom_reports.action_report_fee_defaulter_pdf').report_action(self)
