from odoo import models, fields

class ConsolidatedDataReport(models.TransientModel):
    _name = 'wizard.consolidated.data.report'
    _description = 'Consolidated Data Report Wizard'

    branch_id = fields.Many2one('res.branch', string='Branch')  # Adjust the model name if needed



    def generate_data_report(self):
        # This method will trigger the report generation
        self.ensure_one()
        data = {
            'branch_id': self.branch_id.id,

        }

        return {
            'type': 'ir.actions.report',
            'report_name': 'peb_custom_reports.report_consolidated_data_xlsx',
            'report_type': 'xlsx',
            'data': data,
        }


