from odoo import models, fields, api, _
from datetime import datetime, timedelta
from odoo.exceptions import ValidationError
import logging

_logger = logging.getLogger(__name__)

class AnalysisOfFeeVouchersReport(models.TransientModel):
    _name = 'wizard.analysis.of.fee.vouchers.report'
    _description = 'Wizard for Analysis of Fee Vouchers Report'

    branch_ids = fields.Many2many('res.branch', string="Branch")
    select_all_branches = fields.Boolean(string='Select All Branches')
    student_id = fields.Many2one('res.partner', string="Student ID", ondelete='set null')
    end_date = fields.Date(string="End Date")

    # Period fields for date range selection
    day = fields.Boolean(string='Day')
    period_week = fields.Boolean(string='Week')
    period_month = fields.Boolean(string='Month')
    period_year = fields.Boolean(string='Year')

    admission_year = fields.Selection(
        [(str(year), str(year)) for year in range(datetime.today().year, 1999, -1)],
        string="Admission Year"
    )
    religion = fields.Selection([(
        'Islam', 'Muslim'), ('hindu', 'Hinduism'), ('sikh', 'Sikh'), ('Christian', 'Christianity')], string='Religion')

    gender = fields.Selection([('male', 'Male'), ('female', 'Female')], string='Gender')
    adopted = fields.Boolean(string='Adopted')
    active = fields.Boolean(string='Active')
    employees = fields.Boolean(string='Employees')
    classes = fields.Many2many('school.class', string='Classes')

    student_name = fields.Many2one('res.partner', string='Student Name')

    start_date = fields.Date(string="Start Date")
    start_month = fields.Selection([(
        '1', 'January'), ('2', 'February'), ('3', 'March'), ('4', 'April'), ('5', 'May'), ('6', 'June'),
        ('7', 'July'), ('8', 'August'), ('9', 'September'), ('10', 'October'), ('11', 'November'), ('12', 'December')],
        string="Start Month"
    )

    end_month = fields.Selection([(
        '1', 'January'), ('2', 'February'), ('3', 'March'), ('4', 'April'), ('5', 'May'), ('6', 'June'),
        ('7', 'July'), ('8', 'August'), ('9', 'September'), ('10', 'October'), ('11', 'November'), ('12', 'December')],
        string="End Month"
    )

    concessions = fields.Selection([(
        'deserving case', 'Deserving case'), ('discontinue', 'Discontinue'), ('donor', 'Donor'),
        ('employee child', 'Employee Child'), ('kinship', 'Kinship'), ('orphan', 'Orphan'),
        ('paster child', 'Paster Child'), ('poor', 'Poor'), ('special case', 'Special case')],
        string="Concessions"
    )

    start_year = fields.Selection(
        [(str(year), str(year)) for year in range(datetime.today().year, 1999, -1)],
        string="Start Year",
        default=False,
        help="Please select the Start Year. If you select a start date, make sure to select the end date as well."
    )

    end_year = fields.Selection(
        [(str(year), str(year)) for year in range(datetime.today().year, 1999, -1)],
        string="End Year",
        default=False,
    )

    @api.onchange('start_month', 'start_year')
    def _onchange_start_month_year(self):
        if self.start_month and self.start_year:
            self.start_date = f"{self.start_year}-{self.start_month.zfill(2)}-01"

    @api.onchange('end_month', 'end_year')
    def _onchange_end_month_year(self):
        if self.end_month and self.end_year:
            if int(self.end_month) == 12:
                next_month = 1
                next_year = int(self.end_year) + 1
            else:
                next_month = int(self.end_month) + 1
                next_year = int(self.end_year)

            first_of_next_month = datetime(next_year, next_month, 1)
            self.end_date = first_of_next_month - timedelta(days=1)

    @api.onchange('start_date')
    def _onchange_start_date(self):
        if self.start_date:
            self.start_month = str(self.start_date.month)

    @api.onchange('end_date')
    def _onchange_end_date(self):
        if self.end_date:
            self.end_month = str(self.end_date.month)

    @api.onchange('start_year', 'end_year')
    def _onchange_years(self):
        if self.start_year and self.end_year:
            self.start_date = f"{self.start_year}-01-01"
            self.start_month = '1'
            self.end_date = f"{self.end_year}-12-31"
            self.end_month = '12'

    @api.onchange('day', 'period_week', 'period_month', 'period_year')
    def _onchange_period(self):
        today = datetime.today().date()
        if not any([self.day, self.period_week, self.period_month, self.period_year]):
            self.start_date = False
            self.end_date = False
            self.start_month = False
            self.end_month = False
            return

        if self.day:
            self.start_date = today
            self.end_date = today
            self.start_month = str(today.month)
            self.end_month = str(today.month)

        elif self.period_week:
            start_of_week = today - timedelta(days=today.weekday())  # Start of this week
            end_of_week = start_of_week + timedelta(days=6)  # End of this week
            self.start_date = start_of_week
            self.end_date = end_of_week
            self.start_month = str(start_of_week.month)
            self.end_month = str(end_of_week.month)

        elif self.period_month:
            start_of_month = today.replace(day=1)
            end_of_month = (start_of_month.replace(month=today.month + 1) - timedelta(
                days=1)) if today.month != 12 else today.replace(year=today.year + 1, month=1, day=1) - timedelta(
                days=1)
            self.start_date = start_of_month
            self.end_date = end_of_month
            self.start_month = str(start_of_month.month)
            self.end_month = str(end_of_month.month)

            self.start_year = str(start_of_month.year)
            self.end_year = str(end_of_month.year)

        elif self.period_year:
            start_of_year = today.replace(month=1, day=1)
            end_of_year = today.replace(month=12, day=31)
            self.start_date = start_of_year
            self.end_date = end_of_year
            self.start_month = '1'
            self.end_month = '12'

    @api.constrains('adopted', 'active', 'employees')
    def _check_status_only_one_selected(self):
        status_count = sum([self.adopted, self.active, self.employees])
        if status_count > 1:
            raise ValidationError("You can only select one status: Adopted, Active, or Employees.")

    def get_period_dates(self):
        today = fields.Date.today()
        return self.start_date, self.end_date

    @api.onchange('branch_ids')
    def _sort_branches(self):
        if self.branch_ids:
            # Group boarding houses at the top, followed by other branches alphabetically
            sorted_branches = sorted(
                self.branch_ids, key=lambda b: (
                    'boarding' not in b.name.lower(),  # Ensure boarding branches come first, case-insensitive
                    b.name  # Sort other branches alphabetically
                )
            )
            self.branch_ids = [(6, 0, [b.id for b in sorted_branches])]

    @api.onchange('select_all_branches')
    def _onchange_select_all(self):
        if self.select_all_branches:
            all_branches = self.env['res.branch'].search([])  # Fetch all branches
            # Sort all branches so that boarding branches come first
            sorted_branches = sorted(
                all_branches, key=lambda b: (
                    'boarding' not in b.name.lower(),  # Ensure boarding branches come first, case-insensitive
                    b.name  # Then sort alphabetically
                )
            )
            self.branch_ids = [(6, 0, [b.id for b in sorted_branches])]
        else:
            self.branch_ids = [(5, 0, 0)]  # Clear selection

    def reset_form(self):
        self.start_year = None
        self.end_year = None
        self.start_date = None
        self.end_date = None
        self.religion = ""
        self.student_id = None
        self.adopted = False
        self.active = False
        self.employees = False
        self.classes = []
        self.student_name = None
        self.start_month = ""
        self.end_month = ""
        self.concessions = ""
        self.branch_ids = []
        return {
            'name': _('Analysis Of Fee Voucher Report'),
            'type': 'ir.actions.act_window',
            'res_model': 'wizard.analysis.of.fee.vouchers.report',
            'view_mode': 'form',
            'view_id': self.env.ref('peb_custom_reports.view_wizard_analysis_of_fee_vouchers_form').id,
            'target': 'new',
        }

    def generate_report(self):
        start_date, end_date = self.get_period_dates()

        data = {
            'start_date': start_date,
            'end_date': end_date,
            'branch_id': self.branch_ids.ids if self.branch_ids.ids else None,
            'student_id': self.student_id.id if self.student_id else None,
            'religion': self.religion if self.religion else None,
            'gender': self.gender if self.gender else None,
            'concessions': self.concessions if self.concessions else None,
        }

        if not data['start_date'] or not data['end_date']:
            raise ValidationError(_("Start Date and End Date are required."))

        return {
            'type': 'ir.actions.report',
            'report_name': 'peb_custom_reports.report_analysis_of_fee_vouchers_xlsx',
            'report_type': 'xlsx',
            'data': data,
        }
