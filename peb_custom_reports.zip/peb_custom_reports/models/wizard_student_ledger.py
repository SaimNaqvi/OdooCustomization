from odoo import api, fields, models, _
from odoo.exceptions import UserError
from datetime import date, timedelta, datetime
from odoo.exceptions import ValidationError


class WizardReportStudentLedger(models.TransientModel):
    _name = 'wizard.report.student.ledger'
    _description = 'Wizard Report for Student Ledger'

    branch_ids = fields.Many2many('res.branch', string="Branches")
    student_code = fields.Char(string="Student Code")
    end_date = fields.Date(string="End Date")

    # Period fields for date range selection
    day = fields.Boolean(string='Day')
    period_week = fields.Boolean(string='Week')
    period_month = fields.Boolean(string='Month')
    period_year = fields.Boolean(string='Year')

    admission_year = fields.Selection(
        [(str(year), str(year)) for year in range(datetime.today().year, 1999, -1)],
        string="Admission Year"
    )
    religion = fields.Selection([(
        'Islam', 'Muslim'), ('hindu', 'Hinduism'), ('sikh', 'Sikh'), ('Christian', 'Christianity')], string='Religion')

    gender = fields.Selection([('male', 'Male'), ('female', 'Female')], string='Gender')
    adopted = fields.Boolean(string='Adopted')
    active = fields.Boolean(string='Active')
    employees = fields.Boolean(string='Employees')
    classes = fields.Many2many('school.class', string='Classes')

    student_name = fields.Many2one('res.partner', string='Student Name', domain=[('title', '=', 'Student')])

    start_date = fields.Date(string="Start Date")
    start_month = fields.Selection([(
        '1', 'January'), ('2', 'February'), ('3', 'March'), ('4', 'April'), ('5', 'May'), ('6', 'June'),
        ('7', 'July'), ('8', 'August'), ('9', 'September'), ('10', 'October'), ('11', 'November'), ('12', 'December')],
        string="Start Month"
    )

    end_month = fields.Selection([(
        '1', 'January'), ('2', 'February'), ('3', 'March'), ('4', 'April'), ('5', 'May'), ('6', 'June'),
        ('7', 'July'), ('8', 'August'), ('9', 'September'), ('10', 'October'), ('11', 'November'), ('12', 'December')],
        string="End Month"
    )

    concessions = fields.Selection([(
        'deserving case', 'Deserving case'), ('discontinue', 'Discontinue'), ('donor', 'Donor'),
        ('employee child', 'Employee Child'), ('kinship', 'Kinship'), ('orphan', 'Orphan'),
        ('paster child', 'Paster Child'), ('poor', 'Poor'), ('special case', 'Special case')],
        string="Concessions"
    )
    start_year = fields.Selection(
        [(str(year), str(year)) for year in range(datetime.today().year, 1999, -1)],
        string="Start Year",
        default=False,
        help="Please select the Start Year. If you select a start date, make sure to select the end date as well."
    )
    end_year = fields.Selection(
        [(str(year), str(year)) for year in range(datetime.today().year, 1999, -1)],
        string="End Year",
        default=False,

    )

    @api.onchange('start_month', 'start_year')
    def _onchange_start_month_year(self):
        if self.start_month and self.start_year:
            # Automatically calculate the start date as the 1st day of the selected month and year
            self.start_date = f"{self.start_year}-{self.start_month.zfill(2)}-01"

    @api.onchange('end_month', 'end_year')
    def _onchange_end_month_year(self):
        if self.end_month and self.end_year:
            # Automatically calculate the end date as the last day of the selected month and year
            if int(self.end_month) == 12:
                next_month = 1
                next_year = int(self.end_year) + 1
            else:
                next_month = int(self.end_month) + 1
                next_year = int(self.end_year)

            # Calculate the last day of the selected month
            first_of_next_month = datetime(next_year, next_month, 1)
            self.end_date = first_of_next_month - timedelta(days=1)

    @api.onchange('start_date')
    def _onchange_start_date(self):
        if self.start_date:
            # Automatically set the start month based on the selected start date
            self.start_month = str(self.start_date.month)

    @api.onchange('end_date')
    def _onchange_end_date(self):
        if self.end_date:
            # Automatically set the end month based on the selected end date
            self.end_month = str(self.end_date.month)

    @api.onchange('start_year', 'end_year')
    def _onchange_years(self):
        # Automatically set the start and end month, start date, and end date when start and end year are selected
        if self.start_year and self.end_year:
            # Start Date is always the 1st of January for the selected start year
            self.start_date = f"{self.start_year}-01-01"
            self.start_month = '1'  # January

            # End Date is always the 31st of December for the selected end year
            self.end_date = f"{self.end_year}-12-31"
            self.end_month = '12'  # December

    @api.onchange('day', 'period_week', 'period_month', 'period_year')
    def _onchange_period(self):
        today = datetime.today().date()

        # Clear fields when no period type is selected
        if not any([self.day, self.period_week, self.period_month, self.period_year]):
            self.start_date = False
            self.end_date = False
            self.start_month = False
            self.end_month = False
            return

        if self.day:
            self.start_date = today
            self.end_date = today
            self.start_month = str(today.month)
            self.end_month = str(today.month)



        elif self.period_week:

            # Start of the week is today's date (current date)

            start_of_week = today

            # End of the week is 6 days before the start of the week

            end_of_week = start_of_week - timedelta(days=6)

            # Set the start and end dates

            self.start_date = start_of_week

            self.end_date = end_of_week

            # Set the start and end months based on the start and end dates

            self.start_month = str(start_of_week.month)

            self.end_month = str(end_of_week.month)

        elif self.period_month:
            # For Month, set the first and last day of the current month
            start_of_month = today.replace(day=1)
            if today.month == 12:
                end_of_month = today.replace(year=today.year + 1, month=1, day=1) - timedelta(days=1)
            else:
                end_of_month = today.replace(month=today.month + 1, day=1) - timedelta(days=1)
            self.start_date = start_of_month
            self.end_date = end_of_month
            self.start_month = str(start_of_month.month)
            self.end_month = str(end_of_month.month)

            # Automatically set start and end year based on the start and end dates
            self.start_year = str(start_of_month.year)
            self.end_year = str(end_of_month.year)


        elif self.period_year:
            start_of_year = today.replace(month=1, day=1)
            end_of_year = today.replace(month=12, day=31)
            self.start_date = start_of_year
            self.end_date = end_of_year
            self.start_month = '1'
            self.end_month = '12'

    @api.onchange('student_name')
    def _onchange_student_id(self):
        if self.student_name:
            # Automatically fill student_code based on selected student
            self.student_code = self.student_name.student_code

    @api.onchange('student_code')
    def _onchange_student_code(self):
        if self.student_code:
            # Search for the student based on the student_code
            student = self.env['res.partner'].search(
                [('student_code', '=', self.student_code), ('title', '=', 'Student')], limit=1)
            if student:
                # Automatically fill student_id based on the entered student_code
                self.student_name = student.id

    @api.constrains('adopted', 'active', 'employees')
    def _check_status_only_one_selected(self):
        # Ensure only one of 'adopted', 'active', or 'employees' is selected
        status_count = sum([self.adopted, self.active, self.employees])
        if status_count > 1:
            raise ValidationError("You can only select one status: Adopted, Active, or Employees.")

    def get_period_dates(self):
        today = fields.Date.today()
        start_date = self.start_date
        end_date = self.end_date
        return start_date, end_date

    def get_period_dates(self):
        today = fields.Date.today()
        start_date = self.start_date
        end_date = self.end_date
        return start_date, end_date

    def reset_form(self):
        # Reset fields to appropriate values based on their types
        self.start_year = None
        self.end_year = None
        self.start_date = None
        self.end_date = None
        self.religion = ""
        self.student_code = None
        self.adopted = False
        self.active = False
        self.employees = False  # Should be a boolean, so reset to False
        self.classes = []  # Reset to an empty list
        self.student_name = None
        self.start_month = ""
        self.end_month = ""
        self.concessions = ""
        self.branch_id = []

        # Return the view to stay on the same wizard page
        return {
            'name': _('Student Ledger Report'),
            'type': 'ir.actions.act_window',
            'res_model': 'wizard.report.student.ledger',
            'view_mode': 'form',
            'view_id': self.env.ref('peb_custom_reports.view_student_ledger_report_wizard_form').id,
            'target': 'new',  # Keeps the wizard open in a modal
        }

    def generate_report(self):
        today = fields.Date.today()

        # Get period start and end dates
        start_date, end_date = self.get_period_dates()

        # Prepare data for the report
        data = {
            'form': {
                'start_date': start_date,
                'end_date': end_date,
                'branch_ids': self.branch_ids.ids if self.branch_ids else None,
                'adopted': self.adopted,
                'employees': self.employees,
                'classes': self.classes.ids,
                'active': self.active,
                'admission_year': self.admission_year,
                'religion': self.religion,
                'gender': self.gender,
                'student_name': self.student_name if self.student_name else None,
            }
        }

        # Return the action to generate the report
        return {
            'type': 'ir.actions.report',
            'report_name': 'peb_custom_reports.report_student_ledger_xlsx',
            'report_type': 'xlsx',
            'data': data,
        }

    def generate_pdf_report(self):
        """Generate PDF Report"""
        return self.env.ref('peb_custom_reports.action_student_ledger_report_pdf').report_action(self)
