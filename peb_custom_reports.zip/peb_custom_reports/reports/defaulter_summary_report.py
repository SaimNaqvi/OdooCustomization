from odoo import models, fields, _
import logging
from collections import defaultdict
from dateutil.relativedelta import relativedelta
from datetime import datetime


class DefaulterSummaryXlsx(models.AbstractModel):
    _name = 'report.peb_custom_reports.report_defaulter_summary_xlsx'
    _inherit = 'report.report_xlsx.abstract'

    def format_class_name(self, class_name):
        """Format the class name to capitalized form"""
        if class_name == 'nur':
            return 'Nur'
        elif class_name == 'prep':
            return 'Prep'
        return class_name.capitalize()

    def get_month_range(self, start_date, end_date):
        """Generate month labels (e.g., January) between start_date and end_date"""
        current = start_date.replace(day=1)
        end = end_date.replace(day=1)
        months = []
        while current <= end:
            months.append(current.strftime('%B'))  # e.g., 'January'
            current += relativedelta(months=1)
        return months

    def generate_xlsx_report(self, workbook, data, wizard):
        # Formatting styles
        title_format = workbook.add_format({
            'bold': True,
            'font_size': 16,
            'align': 'center',
            'valign': 'vcenter'
        })
        header_format = workbook.add_format({
            'bold': True,
            'align': 'left',
            'font_size': 16,
            'valign': 'vcenter'
        })
        gap_row_format = workbook.add_format({
            'bg_color': '#D9EAD3',  # Light green background color
            'border': 1,
            'valign': 'vcenter',
            'align': 'center',
        })
        grand_total_format = workbook.add_format({
            'bold': True,
            'border': 1,
            'font_size': 16,
            'valign': 'vcenter',
            'align': 'left',
        })
        integer_format = workbook.add_format({
            'border': 1,
            'valign': 'vcenter',
            'align': 'left',
            'num_format': '0'  # No decimal points, integer format
        })
        student_name_format = workbook.add_format({
            'border': 1,
            'valign': 'vcenter',
            'align': 'left',
        })
        ger_format = workbook.add_format({
            'border': 1,
            'valign': 'vcenter',
            'align': 'left',
            'num_format': '0'  # No decimal points, integer format
        })

        # Fetching the data passed from the wizard
        branch_ids = wizard.branch
        start_date = wizard.start_date
        end_date = wizard.end_date
        till_date = wizard.till_date or fields.Date.today()
        concessions = wizard.concessions
        religion = wizard.religion
        gender = wizard.gender
        classes = wizard.classes
        if till_date and till_date <= end_date:
            end_date = till_date
        # Use current date if till_date not selected
        till_date = wizard.till_date if hasattr(wizard, 'till_date') and wizard.till_date else datetime.today().date()

        # Format all dates
        # Get dates from wizard
        start_date = wizard.start_date
        end_date = wizard.end_date
        till_date = getattr(wizard, 'till_date', None) or datetime.today().date()

        # Format with numeric months
        start_str = start_date.strftime('%d-%m-%Y') if start_date else ''
        end_str = end_date.strftime('%d-%m-%Y') if end_date else ''
        till_str = till_date.strftime('%d-%m-%Y')

        # Determine the fiscal year and months
        months = self.get_month_range(start_date, end_date)

        # Initialize grand totals for all branches
        grand_total_students_all_branch = 0
        grand_total_fees_all_branch = 0
        row_idx = 0

        for branch in branch_ids:
            sheet = workbook.add_worksheet(f'Defaulter Summary - {branch.name}')

            heading = f"Defaulter Summary Report for {start_str}, {end_str} Till date {till_str}"
            # Apply the heading to merged Excel cells
            sheet.merge_range(row_idx, 0, row_idx, len(months) + 3, heading, title_format)

            row_idx += 1

            # Sub-headers
            sub_headers = ['Serial No', 'Student Name'] + months + ['Total Fees']

            # Common domain filters
            domain = [
                ('branch_id', '=', branch.id),
                ('state', '=', 'posted'),
                ('invoice_date', '>=', start_date),
                ('invoice_date', '<=', end_date),
            ]
            if religion:
                domain.append(('partner_id.religion', '=', religion))
            if gender:
                domain.append(('partner_id.gender', '=', gender))
            if wizard.concessions:
                domain.append(('concession_percent', '=', wizard.concessions))
            if classes:
                domain.append(('x_studio_grade', '=', classes.mapped('name')))
            if wizard.active:
                domain.append(('partner_id.current_enroll_status', '=', 'Enrolled'))

            if till_date:
                domain += ['|',
                           ('ol_payment_date', '=', False),
                           ('ol_payment_date', '>', till_date)]

            invoices = self.env['account.move'].sudo().search(domain)

            student_fees = defaultdict(lambda: {
                'student_name': '',
                'class': '',
                'new_homeroom': '',
                'monthly_fees': defaultdict(float),
                'total_fees': 0.0,
                'enrollment_status': ''
            })

            # Preload homerooms
            partner_homerooms = self.env['res.partner'].sudo().search_read([], ['id', 'new_homeroom'])
            new_homeroom_dict = {p['id']: p['new_homeroom'] for p in partner_homerooms}

            for inv in invoices:
                if inv.invoice_date_due:
                    month_label = inv.invoice_date_due.strftime('%B')  # Dynamic month name

                    amount = sum(inv._get_reconciled_payments().mapped('amount')) if inv.payment_state in ['paid',
                                                                                                           'in_payment',
                                                                                                           'partial'] else inv.amount_total
                    student_id = inv.partner_id.id

                    student_fees[student_id]['student_name'] = inv.partner_id.name or ''
                    student_fees[student_id]['class'] = inv.x_studio_grade or ''
                    student_fees[student_id]['new_homeroom'] = new_homeroom_dict.get(student_id, '')
                    student_fees[student_id]['enrollment_status'] = inv.x_studio_enrollment_state.name or 'N/A'
                    student_fees[student_id]['monthly_fees'][month_label] += amount
                    student_fees[student_id]['total_fees'] += amount

            # Group students by class and homeroom
            class_homeroom_groups = defaultdict(lambda: defaultdict(list))
            for student_id, fees in student_fees.items():
                class_homeroom_groups[fees['class']][fees['new_homeroom']].append((student_id, fees))

            def new_homeroom_sort_key(new_homeroom):
                order = ['Earth', 'Mars', 'Jupiter', 'Red', 'Green', 'Blue']
                return order.index(new_homeroom) if new_homeroom in order else len(order)

            def class_sort_key(class_name):
                name = str(class_name).strip().lower()

                # Define exact matching rules
                if name in ['nur', 'nursery', 'Nur', 'NUR']:
                    return (0,)
                elif name in ['prep', 'PREP', 'Prep', 'kg', 'kindergarten']:
                    return (1,)

                # Try to parse as number: "1", "2", "10", etc.
                try:
                    return (2, int(name))
                except ValueError:
                    pass

                # Fallback for any unknown or messy name
                return (3, name)

            grand_total_students = 0
            grand_total_fees = 0

            for class_name, new_homeroom_groups in sorted(class_homeroom_groups.items(),
                                                          key=lambda x: class_sort_key(x[0])):
                class_total_fees = 0.0
                class_total_students = 0

                for new_homeroom in sorted(new_homeroom_groups.keys(), key=new_homeroom_sort_key):
                    students = new_homeroom_groups[new_homeroom]
                    section_heading = f"Class: {self.format_class_name(class_name)}"
                    if new_homeroom:
                        section_heading += f" - Section: {new_homeroom}"

                    sheet.merge_range(row_idx, 0, row_idx, len(months) + 3, section_heading, header_format)
                    row_idx += 1

                    sheet.write_row(row_idx, 0, sub_headers, header_format)
                    row_idx += 1

                    sorted_students = sorted(students, key=lambda x: x[1]['student_name'])

                    for i, (student_id, fees) in enumerate(sorted_students, start=1):
                        row_data = [
                            i,
                            f"{fees['student_name']} ({fees['enrollment_status']})",
                        ]
                        for month in months:
                            row_data.append(int(fees['monthly_fees'].get(month, 0.0)))

                        row_data.append(int(fees['total_fees']))
                        sheet.write_row(row_idx, 0, row_data, ger_format)
                        row_idx += 1

                        class_total_students += 1
                        class_total_fees += fees['total_fees']
                        grand_total_students += 1
                        grand_total_fees += fees['total_fees']

                # Write class totals
                sheet.write(row_idx, 1, "Total Defaulter Fees", header_format)
                sheet.write(row_idx, 2, int(class_total_fees), integer_format)
                row_idx += 1

                sheet.write(row_idx, 1, "Total Defaulter Students", header_format)
                sheet.write(row_idx, 2, class_total_students, integer_format)
                row_idx += 1

            grand_total_students_all_branch += grand_total_students
            grand_total_fees_all_branch += grand_total_fees

            # Final totals row
        sheet.merge_range(row_idx, 0, row_idx, len(months) + 3, "", gap_row_format)
        row_idx += 1

        sheet.write(row_idx, 1, "Grand Total Students", grand_total_format)
        sheet.write(row_idx, 2, grand_total_students_all_branch, grand_total_format)
        row_idx += 1

        sheet.write(row_idx, 1, "Grand Total Fees", grand_total_format)
        sheet.write(row_idx, 2, int(grand_total_fees_all_branch), grand_total_format)
        row_idx += 1

        for col_num in range(len(sub_headers)):
            sheet.set_column(col_num, col_num, 20)

        last_row = row_idx - 1
        sheet.set_row(last_row, None, grand_total_format)