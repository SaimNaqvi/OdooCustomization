from odoo import models
from collections import defaultdict


class StudentReportXlsx(models.AbstractModel):
    _name = 'report.peb_custom_reports.student_report_xlsx'
    _inherit = 'report.report_xlsx.abstract'

    def generate_xlsx_report(self, workbook, data, wizard):
        sheet = workbook.add_worksheet("Student Report")

        # Define formats
        header_format = workbook.add_format({'bold': True, 'align': 'center', 'bg_color': '#D3D3D3', 'border': 1})
        cell_format = workbook.add_format({'align': 'center', 'border': 1})
        class_format = workbook.add_format({'bold': True, 'font_size': 12, 'align': 'center', 'border': 1})
        total_format = workbook.add_format({'bold': True, 'align': 'center', 'border': 1, 'bg_color': '#FFFF99'})
        class_total_format = workbook.add_format({'bold': True, 'align': 'center', 'border': 1, 'bg_color': '#CCE5FF'})
        grand_total_format = workbook.add_format({'bold': True, 'align': 'center', 'border': 1, 'bg_color': '#FFCC99'})

        # Header Setup
        sheet.merge_range('A1:A2', 'Class-Section', header_format)
        sheet.merge_range('B1:D1', 'Christian', header_format)
        sheet.merge_range('E1:G1', 'Muslim', header_format)
        sheet.merge_range('H1:J1', 'Sikh', header_format)
        sheet.write('B2', 'Boys', header_format)
        sheet.write('C2', 'Girls', header_format)
        sheet.write('D2', 'Total Christian', header_format)
        sheet.write('E2', 'Boys', header_format)
        sheet.write('F2', 'Girls', header_format)
        sheet.write('G2', 'Total Muslim', header_format)
        sheet.write('H2', 'Boys', header_format)
        sheet.write('I2', 'Girls', header_format)
        sheet.write('J2', 'Total Sikh', header_format)
        sheet.write('K1', 'Total number of students in class', total_format)

        # Data Fetching and Aggregation
        students = self.env['res.partner'].search([
            ('current_enroll_status', '=', 'Enrolled'),
            ('is_student', '=', True),
            ('title', '=', 'Student'),
            ('branch_id.name', '=', 'KINNAIRD ACADEMY HIGH SCHOOL FOR GIRLS')
        ])

        report_data = defaultdict(lambda: {'Christian': {'Boys': 0, 'Girls': 0},
                                           'Islam': {'Boys': 0, 'Girls': 0},
                                           'Sikh': {'Boys': 0, 'Girls': 0}})

        for student in students:
            class_section = f"{student.current_grade_selection}-{student.new_homeroom}"
            gender = 'Boys' if student.gender == 'male' else 'Girls'
            religion = student.religion.capitalize() if student.religion else ''

            if religion in report_data[class_section]:
                report_data[class_section][religion][gender] += 1

        # Custom sorting for classes and homerooms
        def class_sort_key(class_section):
            class_name, _ = class_section.split('-')
            predefined_classes = {'nur': 0, 'prep': 1}
            class_name = class_name.lower()  # Ensure case-insensitivity

            if class_name in predefined_classes:
                return (predefined_classes[class_name],)
            elif class_name.isdigit():
                return (2, int(class_name))
            return (3, class_name)

        # Writing Data to Sheet
        sorted_sections = sorted(report_data.keys(), key=class_sort_key)
        row = 2
        previous_class = None
        class_wise_boys_total = {'Christian': 0, 'Islam': 0, 'Sikh': 0}
        class_wise_girls_total = {'Christian': 0, 'Islam': 0, 'Sikh': 0}
        class_wise_total_students = 0

        grand_boys_total = {'Christian': 0, 'Islam': 0, 'Sikh': 0}
        grand_girls_total = {'Christian': 0, 'Islam': 0, 'Sikh': 0}

        for class_section in sorted_sections:
            current_class, section = class_section.split('-')

            if current_class != previous_class and previous_class is not None:
                # Add class-wise total row
                sheet.write(row, 0, f"Total {previous_class}", class_total_format)
                for col, religion in enumerate(['Christian', 'Islam', 'Sikh']):
                    sheet.write(row, 1 + col * 3, class_wise_boys_total[religion], class_total_format)
                    sheet.write(row, 2 + col * 3, class_wise_girls_total[religion], class_total_format)
                    sheet.write(row, 3 + col * 3, class_wise_boys_total[religion] + class_wise_girls_total[religion],
                                class_total_format)
                sheet.write(row, 10, class_wise_total_students, class_total_format)

                # Reset class totals and move to the next row
                row += 1
                class_wise_boys_total = {'Christian': 0, 'Islam': 0, 'Sikh': 0}
                class_wise_girls_total = {'Christian': 0, 'Islam': 0, 'Sikh': 0}
                class_wise_total_students = 0

            # Write class-section data
            sheet.write(row, 0, class_section, class_format)
            religions = report_data[class_section]
            total_students = sum(
                religions[religion]['Boys'] + religions[religion]['Girls']
                for religion in religions
            )

            for religion in ['Christian', 'Islam', 'Sikh']:
                class_wise_boys_total[religion] += religions[religion]['Boys']
                class_wise_girls_total[religion] += religions[religion]['Girls']
                grand_boys_total[religion] += religions[religion]['Boys']
                grand_girls_total[religion] += religions[religion]['Girls']

            class_wise_total_students += total_students

            for col, religion in enumerate(['Christian', 'Islam', 'Sikh']):
                sheet.write(row, 1 + col * 3, religions[religion]['Boys'], cell_format)
                sheet.write(row, 2 + col * 3, religions[religion]['Girls'], cell_format)
                sheet.write(row, 3 + col * 3, religions[religion]['Boys'] + religions[religion]['Girls'], cell_format)

            sheet.write(row, 10, total_students, total_format)

            previous_class = current_class
            row += 1

        # Add final class total for the last class
        if previous_class is not None:
            sheet.write(row, 0, f"Total {previous_class}", class_total_format)
            for col, religion in enumerate(['Christian', 'Islam', 'Sikh']):
                sheet.write(row, 1 + col * 3, class_wise_boys_total[religion], class_total_format)
                sheet.write(row, 2 + col * 3, class_wise_girls_total[religion], class_total_format)
                sheet.write(row, 3 + col * 3, class_wise_boys_total[religion] + class_wise_girls_total[religion],
                            class_total_format)
            sheet.write(row, 10, class_wise_total_students, class_total_format)
            row += 1

        # Add Grand Total Row
        sheet.write(row, 0, "Total", grand_total_format)
        for col, religion in enumerate(['Christian', 'Islam', 'Sikh']):
            total_boys = grand_boys_total[religion]
            total_girls = grand_girls_total[religion]
            sheet.write(row, 1 + col * 3, total_boys, grand_total_format)
            sheet.write(row, 2 + col * 3, total_girls, grand_total_format)
            sheet.write(row, 3 + col * 3, total_boys + total_girls, grand_total_format)

        total_students_all = sum(
            grand_boys_total[rel] + grand_girls_total[rel] for rel in ['Christian', 'Islam', 'Sikh'])
        sheet.write(row, 10, total_students_all, grand_total_format)
        row += 2  # Add some space before the next table

        # Second Table: Total Counts for Gender and Religion
        sheet.write(row, 0, "Total Boys", total_format)
        sheet.write(row, 1, grand_boys_total['Christian'] + grand_boys_total['Islam'] + grand_boys_total['Sikh'],
                    total_format)
        row += 1

        sheet.write(row, 0, "Total Girls", total_format)
        sheet.write(row, 1, grand_girls_total['Christian'] + grand_girls_total['Islam'] + grand_girls_total['Sikh'],
                    total_format)
        row += 1

        sheet.write(row, 0, "Total Christian", total_format)
        sheet.write(row, 1, grand_boys_total['Christian'] + grand_girls_total['Christian'], total_format)
        row += 1

        sheet.write(row, 0, "Total Muslim", total_format)
        sheet.write(row, 1, grand_boys_total['Islam'] + grand_girls_total['Islam'], total_format)
        row += 1

        sheet.write(row, 0, "Total Sikh", total_format)
        sheet.write(row, 1, grand_boys_total['Sikh'] + grand_girls_total['Sikh'], total_format)
        row += 1

