import logging
from odoo import models
import xlsxwriter
from datetime import datetime


class StudentNameListXlsx(models.AbstractModel):
    _name = 'report.peb_custom_reports.report_student_name_list_xlsx'
    _inherit = 'report.report_xlsx.abstract'

    def generate_xlsx_report(self, workbook, data, wizard):
        branches = wizard.branch_id
        if not branches:
            return

        worksheet = workbook.add_worksheet('Student Name List')

        # Define formats
        branch_header_format = workbook.add_format({
            'bold': True, 'font_size': 14, 'align': 'center', 'border': 1
        })
        date_range_format = workbook.add_format({
            'bold': True, 'font_size': 12, 'align': 'center', 'border': 1
        })
        header_format = workbook.add_format({
            'bold': True, 'align': 'center', 'bg_color': '#D3D3D3', 'border': 1
        })
        normal_format_center = workbook.add_format({'align': 'center', 'border': 1})
        normal_format_left = workbook.add_format({'align': 'left', 'border': 1})
        concession_format = workbook.add_format({'align': 'center', 'border': 1, 'num_format': '0.00'})

        # Helper function to format date like "1st February 2025"
        def format_date(date):
            suffix = 'th'
            if 4 <= date.day <= 20:
                suffix = 'th'
            else:
                suffix = {1: 'st', 2: 'nd', 3: 'rd'}.get(date.day % 10, 'th')
            return f"{date.day}{suffix} {date.strftime('%B %Y')}"

        start_date_formatted = format_date(wizard.start_date)
        end_date_formatted = format_date(wizard.end_date)

        # Headers
        worksheet.merge_range('A1:G1', 'Branch: {}'.format(', '.join(branch.name for branch in branches)),
                              branch_header_format)
        worksheet.merge_range('A2:G2', 'Date Range: {} - {}'.format(start_date_formatted, end_date_formatted),
                              date_range_format)

        worksheet.write(3, 0, 'Student Code', header_format)
        worksheet.write(3, 1, 'Roll No', header_format)
        worksheet.write(3, 2, 'Class', header_format)
        worksheet.write(3, 3, 'Name', header_format)
        worksheet.write(3, 4, 'Father\'s Name', header_format)
        worksheet.write(3, 5, 'Con. Sch.', header_format)
        worksheet.write(3, 6, 'Status', header_format)

        row = 4

        # Domain for invoice search
        domain = [
            ('state', '=', 'posted'),
            ('invoice_date_due', '>=', wizard.start_date),
            ('invoice_date_due', '<=', wizard.end_date),
        ]

        if branches:
            domain.append(('branch_id', 'in', branches.ids))
        if wizard.religion:
            domain.append(('partner_id.religion', '=', wizard.religion))
        if wizard.gender:
            domain.append(('partner_id.gender', '=', wizard.gender))
        if wizard.concessions:
            domain.append(('concession_percent', '=', wizard.concessions))
        if wizard.active:
            domain.append(('partner_id.current_enroll_status', '=', 'Enrolled'))
        if wizard.classes:
            class_names = wizard.classes.mapped('name')
            domain.append(('x_studio_grade', 'in', class_names))

        invoices = self.env['account.move'].sudo().search(domain)

        # Unique students by invoice
        unique_students = {}
        for invoice in invoices:
            student = invoice.partner_id
            if student and student.id not in unique_students:
                unique_students[student.id] = invoice

        grouped_students = {}
        for invoice in unique_students.values():
            try:
                class_name = invoice.x_studio_grade if hasattr(invoice, 'x_studio_grade') else 'Unknown'
            except AttributeError:
                class_name = 'Unknown'
            grouped_students.setdefault(class_name, []).append(invoice)

        def class_sort_key(class_name):
            predefined_classes = {'nur': 0, 'prep': 1}
            if class_name.lower() in predefined_classes:
                return (predefined_classes[class_name.lower()],)
            if class_name.isdigit():
                return (2, int(class_name))
            return (3, class_name.lower())

        sorted_class_names = sorted(grouped_students.keys(), key=class_sort_key)
        column_lengths = {'A': 0, 'B': 0, 'C': 0, 'D': 0, 'E': 0, 'F': 0, 'G': 0}

        for class_name in sorted_class_names:
            sorted_students = sorted(grouped_students[class_name], key=lambda inv: inv.partner_id.name.lower())
            for invoice in sorted_students:
                student = invoice.partner_id
                student_code = student.student_code
                roll_no = student.reg_number
                student_name = student.name or ''
                father_name = next((rel.parent_id.name for rel in student.student_relationship_ids if
                                    rel.relationship_type == 'father'), ' ')
                current_enroll_status = student.current_enroll_status.name if student.current_enroll_status else ''
                display_class_name = 'Nur' if class_name.lower() == 'nur' else 'Prep' if class_name.lower() == 'prep' else class_name
                concession_percent = invoice.concession_percent or 0.0

                # Write data to worksheet
                worksheet.write(row, 0, student_code, normal_format_center)
                worksheet.write(row, 1, roll_no, normal_format_center)
                worksheet.write(row, 2, display_class_name, normal_format_center)
                worksheet.write(row, 3, student_name, normal_format_left)
                worksheet.write(row, 4, father_name, normal_format_left)
                worksheet.write_number(row, 5, concession_percent, concession_format)
                worksheet.write(row, 6, current_enroll_status, normal_format_center)

                # Update column width tracker
                column_lengths['A'] = max(column_lengths['A'], len(str(student_code)))
                column_lengths['B'] = max(column_lengths['B'], len(str(roll_no)))
                column_lengths['C'] = max(column_lengths['C'], len(str(display_class_name)))
                column_lengths['D'] = max(column_lengths['D'], len(student_name))
                column_lengths['E'] = max(column_lengths['E'], len(father_name))
                column_lengths['F'] = max(column_lengths['F'], len(f"{concession_percent:.2f}"))
                column_lengths['G'] = max(column_lengths['G'], len(str(current_enroll_status)))

                row += 1

            row += 1  # Space after each class

        # Auto-adjust column widths
        for col_letter, max_len in column_lengths.items():
            worksheet.set_column(f'{col_letter}:{col_letter}', max(max_len + 2, 15))

