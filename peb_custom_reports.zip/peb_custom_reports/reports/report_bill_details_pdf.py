from odoo import models
from datetime import timedelta


class ReportBillDetailsPDF(models.AbstractModel):
    _name = 'report.peb_custom_reports.report_bill_details_pdf'
    _description = 'Bill Detail PDF Report'

    def _get_months_range(self, start_date, end_date):
        current_date = start_date
        months = []
        while current_date <= end_date:
            months.append(current_date.strftime('%b-%Y'))
            current_date = (current_date.replace(day=28) + timedelta(days=4)).replace(day=1)
        return months

    def _get_sorted_classes(self, class_names):
        def sort_key(name):
            name = name.lower()
            if name == 'nur':
                return (0, 'Nur')
            if name == 'prep':
                return (1, 'Prep')
            if name.isdigit():
                return (2, int(name))
            return (3, name)

        return sorted(class_names, key=sort_key)

    def _get_report_values(self, docids, data=None):
        wizard = self.env['wizard.bill.details.report'].browse(docids)

        branch_ids = wizard.branch_id.ids
        start_date = wizard.start_date
        end_date = wizard.end_date
        classes = wizard.classes

        domain = [
            ('branch_id', 'in', branch_ids),
            ('invoice_date_due', '>=', start_date),
            ('invoice_date_due', '<=', end_date),
            ('state', '=', 'posted'),
        ]

        if wizard.religion:
            domain.append(('partner_id.religion', '=', wizard.religion))
        if wizard.gender:
            domain.append(('partner_id.gender', '=', wizard.gender))
        if wizard.concessions:
            domain.append(('concession_percent', '=', wizard.concessions))
        if classes:
            domain.append(('x_studio_grade', 'in', classes.mapped('name')))

        invoices = self.env['account.move'].search(domain)

        invoices_by_class_month = {}
        fee_types = set()
        totals_by_class_month = {}

        for inv in invoices:
            class_name = inv.x_studio_grade or 'Unknown Class'
            month_year = inv.invoice_date_due.strftime('%b-%Y')
            key = (class_name, month_year)

            invoices_by_class_month.setdefault(class_name, {}).setdefault(month_year, []).append(inv)
            totals_by_class_month.setdefault(key, {
                'total_actual_fee': 0,
                'total_tuition_fee': 0,
                'total_amount': 0,
                'fee_totals_dict': {},
                'fee_totals_list': [],
            })

            actual_fee = int(inv.actual_fee) or 0
            tuition_fee = 0
            fee_lines = {}

            for line in inv.invoice_line_ids:
                fee_name = line.product_id.name
                amount = line.price_subtotal
                fee_lines[fee_name] = amount
                if fee_name != 'Tuition Fee':
                    fee_types.add(fee_name)
                if fee_name == 'Tuition Fee':
                    tuition_fee += amount

                # Tally totals
                fee_totals_dict = totals_by_class_month[key]['fee_totals_dict']
                fee_totals_dict[fee_name] = fee_totals_dict.get(fee_name, 0) + amount

            totals_by_class_month[key]['total_actual_fee'] += actual_fee
            totals_by_class_month[key]['total_tuition_fee'] += tuition_fee
            totals_by_class_month[key]['total_amount'] += inv.amount_total

        # Finalize fee_totals_list
        fee_types = sorted([f for f in fee_types if f != 'Tuition Fee'])

        for key, total_data in totals_by_class_month.items():
            total_data['fee_totals_list'] = [
                {'name': fee, 'amount': total_data['fee_totals_dict'].get(fee, 0)}
                for fee in fee_types
            ]

        sorted_classes = self._get_sorted_classes(invoices_by_class_month.keys())
        months_range = self._get_months_range(start_date, end_date)

        return {
            'doc_ids': docids,
            'doc_model': 'wizard.bill.details.report',
            'docs': wizard,
            'invoices_by_class_month': invoices_by_class_month,
            'fee_types': fee_types,
            'sorted_classes': sorted_classes,
            'months_range': months_range,
            'start_date': start_date,
            'end_date': end_date,
            'totals_by_class_month': totals_by_class_month,
        }
