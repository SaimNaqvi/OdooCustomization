from odoo import models, fields
from datetime import datetime, timedelta
import calendar


class BillDetailsXlsx(models.AbstractModel):
    _name = 'report.peb_custom_reports.report_bill_details_xlsx'
    _inherit = 'report.report_xlsx.abstract'

    def generate_xlsx_report(self, workbook, data, wizard):
        sheet = workbook.add_worksheet('Bill Detail Report')
        columns_header = workbook.add_format({'bold': True, 'align': 'center', 'valign': 'vcenter'})
        merge_format = workbook.add_format({
            'bold': 1, 'border': 1, 'align': 'center', 'valign': 'vcenter', 'font_size': 14,
        })
        left_aligned = workbook.add_format({'align': 'left', 'valign': 'vcenter', 'border': 1})
        total_format = workbook.add_format({'bold': True, 'border': 1, 'align': 'center'})

        branch_id = wizard.branch_id.ids
        start_date = wizard.start_date
        end_date = wizard.end_date
        concessions = wizard.concessions
        religion = wizard.religion
        gender = wizard.gender
        classes = wizard.classes

        row = 2

        branch_names = ', '.join(branch.name for branch in wizard.branch_id)
        sheet.merge_range(f'A{row}:T{row}', f"Branch: {branch_names}", merge_format)
        row += 2

        start_str = start_date.strftime('%d-%b-%Y')
        end_str = end_date.strftime('%d-%b-%Y')
        class_name = ', '.join(cls.name for cls in wizard.classes) if wizard.classes else 'All Classes'
        heading = f"Detail of Fee Bills Issued For {start_str} To {end_str} of Class {class_name}"
        sheet.merge_range(f'A{row}:T{row}', heading, merge_format)
        row += 2

        domain = [
            ('branch_id', 'in', branch_id),
            ('invoice_date_due', '>=', start_date),
            ('invoice_date_due', '<=', end_date),
            ('state', '=', 'posted'),
        ]
        if religion:
            domain.append(('partner_id.religion', '=', religion))
        if gender:
            domain.append(('partner_id.gender', '=', gender))
        if concessions:
            domain.append(('concession_percent', '=', concessions))
        if classes:
            class_names = classes.mapped('name')
            domain.append(('x_studio_grade', 'in', class_names))

        invoices = self.env['account.move'].sudo().search(domain)

        invoices_by_class_and_month = {}
        all_fee_types = set()

        for inv in invoices:
            class_name = inv.x_studio_grade or 'Unknown Class'
            month_year = inv.invoice_date_due.strftime('%b-%Y')

            invoices_by_class_and_month.setdefault(class_name, {}).setdefault(month_year, []).append(inv)

            for line in inv.invoice_line_ids:
                all_fee_types.add(line.product_id.name)

        all_fee_types = sorted(f for f in all_fee_types if f != 'Tuition Fee')

        def class_sort_key(name):
            if name.lower() == 'nur':
                return (0, 'Nur')
            if name.lower() == 'prep':
                return (1, 'Prep')
            if name.isdigit():
                return (2, int(name))
            return (3, name)

        sorted_classes = sorted(invoices_by_class_and_month.keys(), key=class_sort_key)

        # Generate list of months
        months_by_year = {}
        current_date = start_date
        while current_date <= end_date:
            month_year = current_date.strftime('%b-%Y')
            months_by_year.setdefault(current_date.year, []).append(month_year)
            current_date = (current_date.replace(day=28) + timedelta(days=4)).replace(day=1)

        row += 2

        for class_name in sorted_classes:
            for year in sorted(months_by_year.keys()):
                for month_year in months_by_year[year]:
                    if month_year not in invoices_by_class_and_month[class_name]:
                        continue

                    sheet.merge_range(f'A{row}:T{row}',
                                      f"Class: {class_name.capitalize()} - Bill Month: {month_year}", merge_format)
                    row += 1

                    headers = ['Serial No.', 'Student Code', 'Roll No.', 'Name', 'Bill No.', 'Actual Fee',
                               'Receive Date', 'Tuition Fee', 'Concession (%)'] + all_fee_types + ['Total']
                    sheet.write_row(f'A{row}', headers, columns_header)
                    row += 1

                    serial_no = 1
                    total_actual_fee = 0
                    total_tuition_fee = 0
                    total_fees = {fee: 0 for fee in all_fee_types}
                    total_amount = 0

                    sorted_invoices = sorted(invoices_by_class_and_month[class_name][month_year],
                                             key=lambda i: i.partner_id.name.lower())

                    for inv in sorted_invoices:
                        student = inv.partner_id
                        fee_lines = {line.product_id.name: line.price_subtotal for line in inv.invoice_line_ids}

                        actual_fee = int(inv.actual_fee) or 0
                        tuition_fee = fee_lines.get('Tuition Fee', 0)
                        concession_percentage = inv.concession_percent or 0

                        total_actual_fee += actual_fee
                        total_tuition_fee += tuition_fee
                        total_amount += inv.amount_total
                        for fee in all_fee_types:
                            total_fees[fee] += fee_lines.get(fee, 0)

                        data_row = [
                            serial_no,
                            student.student_code or '',
                            student.roll_no or '',
                            student.name or '',
                            inv.name or '',
                            actual_fee,
                            inv.ol_payment_date_compute.strftime('%d-%b-%y') if inv.ol_payment_date_compute else '',
                            tuition_fee,
                            round(concession_percentage, 2)
                        ]
                        for fee in all_fee_types:
                            data_row.append(fee_lines.get(fee, 0))
                        data_row.append(inv.amount_total)

                        sheet.write_row(f'A{row}', data_row, columns_header)
                        sheet.write(row, 3, student.name or '', left_aligned)
                        row += 1
                        serial_no += 1

                    # Totals
                    total_row = ['Total:', '', '', '', '', int(total_actual_fee), '', total_tuition_fee, ''] + \
                                [total_fees[fee] for fee in all_fee_types] + [total_amount, '']
                    sheet.write_row(f'A{row}', total_row, total_format)
                    row += 2

        # --- Grand Totals ---
        row += 1
        sheet.merge_range(f'A{row}:T{row}', "Grand Total Summary", merge_format)
        row += 1

        headers = ['Total Actual Fee', 'Total Tuition Fee'] + all_fee_types + ['Total Amount']
        sheet.write_row(f'A{row}', headers, columns_header)
        row += 1

        grand_total_actual_fee = 0
        grand_total_tuition_fee = 0
        grand_total_fees = {fee: 0 for fee in all_fee_types}
        grand_total_amount = 0

        for class_data in invoices_by_class_and_month.values():
            for month_data in class_data.values():
                for inv in month_data:
                    fee_lines = {line.product_id.name: line.price_subtotal for line in inv.invoice_line_ids}
                    grand_total_actual_fee += int(inv.actual_fee) or 0
                    grand_total_tuition_fee += fee_lines.get('Tuition Fee', 0)
                    for fee in all_fee_types:
                        grand_total_fees[fee] += fee_lines.get(fee, 0)
                    grand_total_amount += inv.amount_total

        data_row = [int(grand_total_actual_fee), grand_total_tuition_fee] + \
                   [grand_total_fees[fee] for fee in all_fee_types] + [grand_total_amount]

        sheet.write_row(f'A{row}', data_row, total_format)
