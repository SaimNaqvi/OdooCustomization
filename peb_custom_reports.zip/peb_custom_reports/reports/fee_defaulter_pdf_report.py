from odoo import models, fields
from datetime import datetime
from collections import defaultdict


class FeeDefaulterReportPDF(models.AbstractModel):
    _name = 'report.peb_custom_reports.fee_defaulter_pdf_report'
    _description = 'Fee Defaulter PDF Report'

    def _get_report_values(self, docids, data=None):
        wizard = self.env['fee.defaulter.wizard'].browse(docids)
        branch = wizard.branch
        start_date = wizard.start_date
        end_date = wizard.end_date
        till_date = wizard.till_date or fields.Date.today()
        classes = wizard.classes
        concessions = wizard.concessions
        branch_ids = branch.ids
        branch_names = ', '.join(branch.mapped('name'))

        # Adjust end_date based on till_date
        if till_date and till_date <= end_date:
            end_date = till_date

        # Build domain
        domain = [
            ('state', '=', 'posted'),
            ('invoice_date', '>=', start_date),
            ('invoice_date', '<=', end_date),
            ('branch_id', 'in', branch_ids),
        ]

        if wizard.active:
            domain.append(('partner_id.active', '=', True))
        elif wizard.adopted:
            domain.append(('partner_id.donor_name', '=', 'donor'))
        elif wizard.employees:
            domain.append(('partner_id.employee', '=', True))
        if concessions:
            domain.append(('concession_percent', '=', concessions))
        if wizard.gender:
            domain.append(('partner_id.gender', '=', wizard.gender))
        if wizard.religion:
            domain.append(('partner_id.religion', '=', wizard.religion))
        if classes:
            class_names = classes.mapped('name')
            domain.append(('x_studio_grade', 'in', class_names))

        if till_date:
            domain += [('invoice_date_due', '<', till_date), '|',
                       ('ol_payment_date', '=', False), ('ol_payment_date', '>', till_date)]

        invoices = self.env['account.move'].sudo().search(domain)

        def class_sort_key(class_name):
            predefined_classes = {'nur': 0, 'prep': 1}
            if class_name.lower() in predefined_classes:
                return (predefined_classes[class_name.lower()],)
            elif class_name.isdigit():
                return (2, int(class_name))
            else:
                return (3, class_name.lower())

        # Group invoices by month and class
        month_class_data = defaultdict(lambda: defaultdict(list))
        for inv in invoices:
            month_year = inv.invoice_date_due.strftime('%b %Y')
            student_class = inv.x_studio_grade or 'No Class'
            month_class_data[month_year][student_class].append(inv)

        # Sort months
        sorted_months = sorted(month_class_data.keys(), key=lambda x: datetime.strptime(x, '%b %Y'))

        return {
            'doc_ids': docids,
            'doc_model': 'fee.defaulter.wizard',
            'docs': wizard,
            'start_date': start_date,
            'end_date': end_date,
            'till_date': till_date,
            'branch_names': branch_names,
            'month_class_data': month_class_data,
            'sorted_months': sorted_months,
            'class_sort_key': class_sort_key,
        }
