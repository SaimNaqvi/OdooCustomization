from odoo import api, models, fields
from collections import defaultdict
from datetime import datetime
from dateutil.relativedelta import relativedelta


class DefaulterSummaryPDF(models.AbstractModel):
    _name = 'report.peb_custom_reports.report_defaulter_summary_pdf_view'
    _description = 'Defaulter Summary PDF Report'

    def get_month_range(self, start_date, end_date):
        current = start_date.replace(day=1)
        end = end_date.replace(day=1)
        months = []
        while current <= end:
            months.append(current.strftime('%B'))
            current += relativedelta(months=1)
        return months

    def class_sort_key(self, class_name):
        name = str(class_name).strip().lower()
        if name in ['Nur', 'nur', 'NUR']:
            return (0,)
        elif name in ['Prep', 'PREP', 'prep']:
            return (1,)
        try:
            return (2, int(name))
        except ValueError:
            return (3, name)

    def new_homeroom_sort_key(self, homeroom):
        order = ['Earth', 'Mars', 'Jupiter', 'Red', 'Green', 'Blue']
        return order.index(homeroom) if homeroom in order else len(order)

    @api.model
    def _get_report_values(self, docids, data=None):
        wizard = self.env['wizard.defaulter.summary.report'].browse(docids)
        start_date = wizard.start_date
        end_date = wizard.end_date
        till_date = wizard.till_date or fields.Date.today()
        months = self.get_month_range(start_date, end_date)

        grand_total_students = 0
        grand_total_fees = 0
        report_data = []

        for branch in wizard.branch:
            branch_dict = {
                'branch_name': branch.name,
                'class_data': []
            }

            domain = [
                ('branch_id', '=', branch.id),
                ('state', '=', 'posted'),
                ('invoice_date', '>=', start_date),
                ('invoice_date', '<=', end_date),
            ]
            if wizard.religion:
                domain.append(('partner_id.religion', '=', wizard.religion))
            if wizard.gender:
                domain.append(('partner_id.gender', '=', wizard.gender))
            if wizard.concessions:
                domain.append(('concession_percent', '=', wizard.concessions))
            if wizard.classes:
                domain.append(('x_studio_grade', '=', wizard.classes.mapped('name')))
            if wizard.active:
                domain.append(('partner_id.current_enroll_status', '=', 'Enrolled'))
            if till_date:
                domain += ['|', ('ol_payment_date', '=', False), ('ol_payment_date', '>', till_date)]

            invoices = self.env['account.move'].sudo().search(domain)

            student_fees = defaultdict(lambda: {
                'student_name': '',
                'monthly_fees': defaultdict(float),
                'total_fees': 0.0,
                'new_homeroom': '',
                'class': '',
            })

            homeroom_map = {
                p.id: p.new_homeroom
                for p in self.env['res.partner'].sudo().search([])
            }

            for inv in invoices:
                if inv.invoice_date_due:
                    month = inv.invoice_date_due.strftime('%B')
                    student_id = inv.partner_id.id
                    amount = inv.amount_total

                    student_fees[student_id]['student_name'] = inv.partner_id.name
                    student_fees[student_id]['monthly_fees'][month] += amount
                    student_fees[student_id]['total_fees'] += amount
                    student_fees[student_id]['class'] = inv.x_studio_grade
                    student_fees[student_id]['new_homeroom'] = homeroom_map.get(student_id, '')

            # Group by class and homeroom
            grouped = defaultdict(lambda: defaultdict(list))
            for sid, fee_data in student_fees.items():
                grouped[fee_data['class']][fee_data['new_homeroom']].append(fee_data)

            for class_name, sections in sorted(grouped.items(), key=lambda x: self.class_sort_key(x[0])):
                class_item = {
                    'class_name': class_name,
                    'sections': []
                }

                for section_name, students in sorted(sections.items(), key=lambda x: self.new_homeroom_sort_key(x[0])):
                    section_data = {
                        'section_name': section_name,
                        'students': students,
                        'total_students': len(students),
                        'total_fees': sum(s['total_fees'] for s in students)
                    }
                    class_item['sections'].append(section_data)
                    grand_total_students += len(students)
                    grand_total_fees += section_data['total_fees']

                branch_dict['class_data'].append(class_item)

            report_data.append(branch_dict)

        return {
            'doc_ids': docids,
            'doc_model': 'wizard.defaulter.summary.report',
            'data': {
                'start_date': start_date,
                'end_date': end_date,
                'till_date': till_date,
                'months': months,
                'grand_total_fees': grand_total_fees,
                'grand_total_students': grand_total_students,
            },
            'report_data': report_data,
        }
