from odoo import models, api
from collections import defaultdict


class StudentBillSummaryPdf(models.AbstractModel):
    _name = 'report.peb_custom_reports.report_student_bill_summary_pdf'
    _description = 'Student Bill Summary PDF'

    def _get_report_values(self, docids, data=None):
        wizard = self.env['wizard.student.bill.summary'].browse(docids)
        start_date = wizard.start_date
        end_date = wizard.end_date
        branch = wizard.branch_id
        month_label = f"{start_date.strftime('%B')} - {end_date.strftime('%B %Y')}"

        invoice_domain = [
            ('state', '=', 'posted'),
            ('invoice_date_due', '>=', start_date),
            ('invoice_date_due', '<=', end_date),
            ('branch_id', '=', branch.id)
        ]
        invoices = self.env['account.move'].sudo().search(invoice_domain)

        # Class-wise grouping
        class_data = defaultdict(lambda: {
            'students': set(),
            'paying_full': set(),
            'concession_amount': 0,
            'net_amount': 0,
            'pending_students': set(),
            'pending_amount': 0,
            'received_amount': 0,
            'actual_fee_total': 0,
        })

        for inv in invoices:
            class_name = inv.x_studio_grade or 'Unknown'
            partner = inv.partner_id

            class_data[class_name]['students'].add(partner.id)
            class_data[class_name]['net_amount'] += inv.amount_total
            concession_amt = max(0, inv.actual_fee - inv.amount_total)
            class_data[class_name]['concession_amount'] += concession_amt
            class_data[class_name]['actual_fee_total'] += inv.actual_fee

            if not inv.concession_percent:
                class_data[class_name]['paying_full'].add(partner.id)

            if inv.payment_state == 'not_paid':
                class_data[class_name]['pending_students'].add(partner.id)
                class_data[class_name]['pending_amount'] += inv.amount_residual

            if inv.payment_state in ['in_payment', 'paid']:
                class_data[class_name]['received_amount'] += inv.amount_total

        # Sort classes like in Excel
        def class_sort_key(class_name):
            predefined = {'nur': 0, 'prep': 1}
            if class_name.lower() in predefined:
                return (predefined[class_name.lower()],)
            if class_name.isdigit():
                return (2, int(class_name))
            return (3, class_name.lower())

        sorted_class_data = []
        totals = {
            'students': 0,
            'paying_full': 0,
            'actual_fee_total': 0,
            'on_concession': 0,
            'concession_amount': 0,
            'net_amount': 0,
            'pending_students': 0,
            'pending_amount': 0,
            'received_amount': 0,
        }

        for class_name in sorted(class_data.keys(), key=class_sort_key):
            data = class_data[class_name]
            student_count = len(data['students'])
            paying_full = len(data['paying_full'])
            on_concession = student_count - paying_full

            # Recalculate actual_fee_total just like Excel version (💯 safe)
            actual_fee_total = sum([
                inv.actual_fee or 0 for inv in invoices
                if (inv.x_studio_grade or 'Unknown') == class_name
            ])

            sorted_class_data.append({
                'class_name': "Nur" if class_name.lower() == "nur" else "Prep" if class_name.lower() == "prep" else class_name,
                'students': student_count,
                'paying_full': paying_full,
                'actual_fee_total': actual_fee_total,
                'on_concession': on_concession,
                'concession_amount': data['concession_amount'],
                'net_amount': data['net_amount'],
                'pending_students': len(data['pending_students']),
                'pending_amount': data['pending_amount'],
                'received_amount': data['received_amount'],
            })
            # Totals
            totals['students'] += student_count
            totals['paying_full'] += paying_full
            totals['actual_fee_total'] += actual_fee_total
            totals['on_concession'] += on_concession
            totals['concession_amount'] += data['concession_amount']
            totals['net_amount'] += data['net_amount']
            totals['pending_students'] += len(data['pending_students'])
            totals['pending_amount'] += data['pending_amount']
            totals['received_amount'] += data['received_amount']

        # Concession Summary
        concession_categories = [100, 75, 50, 25, 0]
        concession_data = {
            percent: {'students': set(), 'receivable_amount': 0, 'actual_fee_total': 0}
            for percent in concession_categories
        }

        for inv in invoices:
            concession_percent = inv.concession_percent or 0
            if concession_percent not in concession_categories:
                continue

            concession_data[concession_percent]['students'].add(inv.partner_id.id)
            concession_data[concession_percent]['receivable_amount'] += inv.amount_total
            concession_data[concession_percent]['actual_fee_total'] += inv.actual_fee

        # Final total for concession table
        total_concession_summary = {
            'students': 0,
            'actual': 0,
            'receivable': 0,
            'concession': 0
        }

        final_concession_data = []
        for percent in concession_categories:
            data = concession_data[percent]
            concession_amount = data['actual_fee_total'] - data['receivable_amount']

            final_concession_data.append({
                'percent': percent,
                'student_count': len(data['students']),
                'actual_fee': data['actual_fee_total'],
                'receivable': data['receivable_amount'],
                'concession': concession_amount
            })

            total_concession_summary['students'] += len(data['students'])
            total_concession_summary['actual'] += data['actual_fee_total']
            total_concession_summary['receivable'] += data['receivable_amount']
            total_concession_summary['concession'] += concession_amount

        total_students = totals['students']
        total_paying_full = totals['paying_full']
        total_actual_fee = totals['actual_fee_total']
        total_on_concession = totals['on_concession']
        total_concession_amt = totals['concession_amount']
        total_net_amt = totals['net_amount']
        total_pending_students = totals['pending_students']
        total_pending_amt = totals['pending_amount']
        total_received_amt = totals['received_amount']

        return {
            'doc_ids': docids,
            'doc_model': 'wizard.student.bill.summary',
            'data': data,
            'wizard': wizard,
            'month_label': month_label,
            'class_data': sorted_class_data,
            'totals': totals,
            'concession_data': final_concession_data,
            'total_concession_summary': total_concession_summary,
            'total_students': total_students,
            'total_paying_full': total_paying_full,
            'total_actual_fee': total_actual_fee,
            'total_on_concession': total_on_concession,
            'total_concession_amt': total_concession_amt,
            'total_net_amt': total_net_amt,
            'total_pending_students': total_pending_students,
            'total_pending_amt': total_pending_amt,
            'total_received_amt': total_received_amt,

        }
