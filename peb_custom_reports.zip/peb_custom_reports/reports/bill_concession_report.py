from odoo import models, fields
import calendar
from datetime import datetime
from dateutil.relativedelta import relativedelta


class FeeConcessionReport(models.AbstractModel):
    _name = 'report.peb_custom_reports.report_fee_concession_xlsx'
    _inherit = 'report.report_xlsx.abstract'

    def generate_xlsx_report(self, workbook, data, wizard):
        overall_sheet = workbook.add_worksheet('Fee Concession')

        # Define formatting styles
        columns_header = workbook.add_format({'bold': True, 'align': 'center', 'valign': 'vcenter', 'border': 1})
        merge_format = workbook.add_format(
            {'bold': 1, 'border': 1, 'align': 'left', 'valign': 'vcenter', 'font_size': 19})
        name_format = workbook.add_format({'align': 'left', 'border': 1})
        center_format = workbook.add_format({'align': 'center', 'border': 1})
        integer_format = workbook.add_format({'align': 'right', 'border': 1, 'num_format': '0'})
        percentage_format = workbook.add_format({'align': 'right', 'border': 1, 'num_format': '0.00'})

        start_date_str = wizard.start_date.strftime('%d-%b-%Y')
        end_date_str = wizard.end_date.strftime('%d-%b-%Y')
        # Retrieve filters from wizard
        branch_id = wizard.branch_id.ids
        start_date = wizard.start_date
        end_date = wizard.end_date
        concessions = wizard.concessions
        religion = wizard.religion
        gender = wizard.gender
        classes = wizard.classes

        branch_records = self.env['res.branch'].sudo().search([('id', 'in', branch_id)])
        branch_names = ', '.join(branch.name for branch in branch_records)

        domain = [
            ('branch_id', 'in', branch_id),
            ('invoice_date_due', '>=', start_date),
            ('invoice_date_due', '<=', end_date),
            ('state', '=', 'posted'),
        ]
        if concessions:
            domain.append(('concession_percent', '=', concessions))
        if classes:
            class_names = classes.mapped('name')
            domain.append(('x_studio_grade', 'in', class_names))
        if gender:
            domain.append(('partner_id.gender', '=', gender))
        if religion:
            domain.append(('partner_id.religion', '=', religion))

        invoices = self.env['account.move'].sudo().search(domain)

        if not invoices:
            overall_sheet.write(0, 0, "No invoices found for the selected criteria.")
            return

        sheet_data = {}
        for inv in invoices:
            student = inv.partner_id
            student_class = inv.x_studio_grade or ''
            invoice_date = inv.invoice_date_due
            invoice_month = invoice_date.strftime('%B %Y')
            invoice_year = invoice_date.year
            invoice_month_number = invoice_date.month

            student_class = {'nur': 'Nur', 'prep': 'Prep'}.get(student_class.lower(), student_class)

            sheet_data.setdefault(invoice_year, {}).setdefault(invoice_month_number, {}).setdefault(student_class, [])

            total_fee = sum(line.price_subtotal for line in inv.invoice_line_ids)
            actual_fee = inv.actual_fee or 0
            concession_percent = inv.concession_percent or 0.0
            concession_amount = round((actual_fee * concession_percent) / 100.0, 0)

            if concession_percent > 0:
                data_row = [
                    '',  # Serial No.
                    student.student_code or '',
                    student.roll_no or '',
                    student.name or '',
                    actual_fee,
                    concession_percent,
                    concession_amount,
                    total_fee,
                ]
                sheet_data[invoice_year][invoice_month_number][student_class].append(data_row)

        def class_sort_key(class_name):
            predefined_classes = {'Nur': 0, 'Prep': 1}
            if class_name in predefined_classes:
                return (predefined_classes[class_name],)
            if class_name.isdigit():
                return (2, int(class_name))
            return (3, class_name.lower())

        row = 3
        overall_sheet.merge_range(f'A{row}:H{row}', f"Branch: {branch_names}", merge_format)
        row += 2

        for year in sorted(sheet_data.keys()):
            for month_number in sorted(sheet_data[year].keys()):
                overall_sheet.merge_range(row, 0, row, 7,
                                          f'Fee Concession Report for {start_date_str} to {end_date_str}', merge_format)

                row += 1

                sorted_classes = sorted(sheet_data[year][month_number].items(), key=lambda x: class_sort_key(x[0]))
                headers = ['Serial No.', 'Student Code', 'Roll No.', 'Name', 'Actual Fee', 'Concession %',
                           'Concession Amount', 'Total Amount']

                for student_class, students in sorted_classes:
                    if not students:
                        continue

                    overall_sheet.merge_range(row, 0, row, 7, f'Class: {student_class}', merge_format)
                    row += 1

                    overall_sheet.write_row(row, 0, headers, columns_header)
                    row += 1

                    students.sort(key=lambda x: x[3].lower())
                    serial_no = 1
                    for data_row in students:
                        data_row[0] = serial_no
                        overall_sheet.write(row, 0, data_row[0], center_format)
                        overall_sheet.write(row, 1, data_row[1], center_format)
                        overall_sheet.write(row, 2, data_row[2], center_format)
                        overall_sheet.write(row, 3, data_row[3], name_format)
                        overall_sheet.write(row, 4, data_row[4], integer_format)  # Actual Fee
                        overall_sheet.write(row, 5, data_row[5], percentage_format)  # Concession %
                        overall_sheet.write(row, 6, data_row[6], integer_format)  # Concession Amount
                        overall_sheet.write(row, 7, data_row[7], integer_format)  # Total Fee
                        row += 1
                        serial_no += 1

                    total_actual_fee = sum(data_row[4] for data_row in students)
                    total_concession_amount = sum(data_row[6] for data_row in students)
                    total_amount = sum(data_row[7] for data_row in students)

                    row += 1
                    overall_sheet.write(row, 3, "Total:", workbook.add_format({'bold': True}))
                    overall_sheet.write(row, 4, total_actual_fee, integer_format)
                    overall_sheet.write(row, 6, total_concession_amount, integer_format)
                    overall_sheet.write(row, 7, total_amount, integer_format)
                    row += 2

        # Auto-adjust column widths
        column_lengths = {col: 0 for col in 'ABCDEFGH'}
        for col_name, header in zip('ABCDEFGH', headers):
            column_lengths[col_name] = len(header)

        for year in sheet_data:
            for month in sheet_data[year]:
                for class_name, students in sheet_data[year][month].items():
                    for data_row in students:
                        for i, col_letter in enumerate('ABCDEFGH'):
                            column_lengths[col_letter] = max(column_lengths[col_letter], len(str(data_row[i])))

        for col_letter, max_len in column_lengths.items():
            overall_sheet.set_column(f'{col_letter}:{col_letter}', max_len + 2)
