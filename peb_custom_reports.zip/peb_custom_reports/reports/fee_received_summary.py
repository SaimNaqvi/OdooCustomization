from odoo import models
from datetime import datetime
import calendar


class FeeReceivedSummaryReport(models.AbstractModel):
    _name = 'report.peb_custom_reports.report_fee_received_summary_xlsx'
    _inherit = 'report.report_xlsx.abstract'

    def generate_xlsx_report(self, workbook, data, wizard):
        # Create the worksheet
        sheet = workbook.add_worksheet('Fee Received Summary')

        # Define some formatting styles
        bold_format = workbook.add_format({'bold': True, 'align': 'center', 'border': 1})
        integer_format = workbook.add_format({'num_format': '#,##0', 'align': 'center', 'border': 1})
        center_format = workbook.add_format({'align': 'center', 'border': 1})
        bold_center_format = workbook.add_format({'bold': True, 'align': 'center', 'border': 1})
        header_format = workbook.add_format({'bold': True, 'align': 'center', 'border': 1, 'bg_color': '#D3D3D3'})

        # Report Header
        branch_name = wizard.branch_id.name if wizard.branch_id else 'N/A'
        sheet.merge_range('A1:P1', f'Branch Name: {branch_name}', bold_center_format)
        sheet.merge_range('A2:P2', f'Fee Received', bold_center_format)
        sheet.merge_range('A3:P3',
                          f'From {wizard.start_date.strftime("%d-%m-%Y")} To {wizard.end_date.strftime("%d-%m-%Y")}',
                          bold_center_format)

        # Header Row
        # Dynamically generate months from start_date to end_date
        start = wizard.start_date
        end = wizard.end_date
        month_range = []

        current = start
        while current <= end:
            month_range.append((current.month, calendar.month_abbr[current.month]))
            if current.month == 12:
                current = current.replace(year=current.year + 1, month=1)
            else:
                current = current.replace(month=current.month + 1)

        headers = ['SR#', 'Reg#', 'Year'] + [m[1] for m in month_range] + ['Total']
        for col_num, header in enumerate(headers):
            sheet.write(4, col_num, header, header_format)
        fee_lines = self._get_fee_data(wizard)
        month_order = [m[0] for m in month_range]
        row = 5
        total_col_sums = {month: 0 for month in range(1, 13)}
        total_grand = 0

        for index, fee in enumerate(fee_lines, start=1):
            sheet.write(row, 0, index, center_format)  # SR#
            sheet.write(row, 1, fee['product_name'], center_format)  # Reg# (Product Name)
            sheet.write(row, 2, fee['year'], center_format)  # Year

            total_amount = 0
            for col, month in enumerate(month_order, start=3):
                amount = fee['monthly_data'][month]
                total_amount += amount
                total_col_sums[month] += amount
                sheet.write(row, col, int(amount), integer_format)

            # Total Column
            sheet.write(row, len(headers) - 1, int(total_amount), integer_format)
            total_grand += total_amount
            row += 1

        # Add Total Row
        sheet.write(row, 0, 'Total:', bold_format)
        for col, month in enumerate(month_order, start=3):
            sheet.write(row, col, int(total_col_sums[month]), bold_format)
        sheet.write(row, len(headers) - 1, int(total_grand), bold_format)

        # Auto-adjust column widths
        for col_num in range(len(headers)):
            sheet.set_column(col_num, col_num, 15)

    def _get_fee_data(self, wizard):
        """
        Fetch and process the fee data based on wizard inputs.
        """
        start_date = wizard.start_date
        end_date = wizard.end_date
        branch_id = wizard.branch_id

        # Fetch invoices for the selected period
        invoices = self.env['account.move'].sudo().search([
            ('branch_id', '=', branch_id.id),
            ('move_type', '=', 'out_invoice'),
            ('state', '=', 'posted'),
            ('ol_payment_date', '>=', start_date),
            ('ol_payment_date', '<=', end_date)
        ])

        # Process invoices
        fee_summary = {}
        for invoice in invoices:
            payment_date = invoice.ol_payment_date or invoice.invoice_date
            invoice_year = invoice.invoice_date.year
            invoice_month = payment_date.month
            for line in invoice.invoice_line_ids:
                product_name = line.product_id.sudo().name or 'N/A'

                key = (product_name, invoice_year)  # Keep products grouped by their actual invoice year
                if key not in fee_summary:
                    fee_summary[key] = {
                        'product_name': product_name,
                        'year': invoice_year,
                        'monthly_data': {month: 0 for month in range(1, 13)}
                    }

                fee_summary[key]['monthly_data'][invoice_month] += line.price_total

        return list(fee_summary.values())
