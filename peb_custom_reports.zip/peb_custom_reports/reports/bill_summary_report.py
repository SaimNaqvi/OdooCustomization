from odoo import models, fields, api
import xlsxwriter
from collections import defaultdict
from datetime import datetime


class StudentBillSummaryXlsx(models.AbstractModel):
    _name = 'report.peb_custom_reports.report_student_bill_summary_xlsx'
    _inherit = 'report.report_xlsx.abstract'

    def generate_xlsx_report(self, workbook, data, wizard):
        worksheet = workbook.add_worksheet('Student Bill Summary')

        start_date = wizard.start_date
        end_date = wizard.end_date
        branch_id = wizard.branch_id

        start_month = fields.Date.from_string(start_date).strftime('%B - %Y')
        end_month = fields.Date.from_string(end_date).strftime('%B - %Y')

        bold_centered = workbook.add_format({'bold': True, 'align': 'center', 'border': 1})
        centered = workbook.add_format({'align': 'center', 'border': 1})
        title_format = workbook.add_format({'bold': True, 'font_size': 14, 'align': 'center'})

        # Dynamic Header Title
        header_title = f"{wizard.branch_id.name}"
        sub_header = f"Summary of Fee Bills Issued For {start_month} to {end_month}"

        # Merge cells for header (A1:J1, A2:J2)
        worksheet.merge_range('A1:J1', header_title, title_format)
        worksheet.merge_range('A2:J2', sub_header, title_format)

        # Define column headers
        headers = [
            "S.#", "Classes", "Students", "Paying Full", "Actual Fee", "On Concession",
            "Concession Amount", "Net Amount", "Pending Student", "Pending Amount", "Received Amount"
        ]
        worksheet.write_row('A4', headers, bold_centered)

        # Get all invoices within the date range
        invoice_domain = [
            ('state', '=', 'posted'),
            ('invoice_date_due', '>=', start_date),
            ('invoice_date_due', '<=', end_date),
            ('branch_id', '=', branch_id.id)
        ]
        invoices = self.env['account.move'].sudo().search(invoice_domain)
        # Initialize class-wise data
        class_data = defaultdict(lambda: {
            'students': set(),         # To track unique students per class
            'paying_full': set(),      # Unique paying full students
            'concession_amount': 0,
            'net_amount': 0,
            'pending_students': set(), # Unique pending students
            'pending_amount': 0,
            'received_amount': 0
        })

        # Process invoices
        for inv in invoices:
            class_name = inv.x_studio_grade or 'Unknown'
            partner = inv.partner_id

            # Add student to class
            class_data[class_name]['students'].add(partner.id)

            # Net Amount (Invoice Total)
            class_data[class_name]['net_amount'] += inv.amount_total

            # Concession Amount = (Actual Fee - Invoice Total)
            concession_amount = inv.actual_fee - inv.amount_total
            class_data[class_name]['concession_amount'] += max(0, concession_amount)

            # Paying Full (if no concession applied to the student)
            if not inv.concession_percent:
                class_data[class_name]['paying_full'].add(partner.id)  # Ensure uniqueness

            # Pending Students & Pending Amount
            if inv.payment_state == 'not_paid':
                class_data[class_name]['pending_students'].add(partner.id)
                class_data[class_name]['pending_amount'] += inv.amount_residual

            # Received Amount
            if inv.payment_state in ['in_payment', 'paid']:
                class_data[class_name]['received_amount'] += inv.amount_total

        # Sorting function for classes
        def class_sort_key(class_name):
            predefined_classes = {'nur': 0, 'prep': 1}  # Priority for Nur & Prep

            if class_name.lower() in predefined_classes:
                return (predefined_classes[class_name.lower()],)
            if class_name.isdigit():
                return (2, int(class_name))
            return (3, class_name.lower())

        # Write data to sheet (Sorted)
        row = 4
        serial = 1
        totals = [0] * len(headers)

        for class_name in sorted(class_data.keys(), key=class_sort_key):
            data = class_data[class_name]
            student_count = len(data['students'])

            # Calculate On Concession
            on_concession = student_count - len(data['paying_full'])

            # Actual Fee = Students × actual fee
            actual_fee_total = sum([
                inv.actual_fee for inv in invoices
                if (inv.x_studio_grade or 'Unknown') == class_name
            ])

            # Capitalize "Nur" and "Prep"
            formatted_class_name = "Nur" if class_name.lower() == "nur" else (
                "Prep" if class_name.lower() == "prep" else class_name
            )

            # Write data to Excel
            worksheet.write(row, 0, serial, centered)
            worksheet.write(row, 1, formatted_class_name, centered)
            worksheet.write(row, 2, student_count, centered)
            worksheet.write(row, 3, len(data['paying_full']), centered)
            worksheet.write(row, 4, actual_fee_total, centered)
            worksheet.write(row, 5, on_concession, centered)
            worksheet.write(row, 6, data['concession_amount'], centered)
            worksheet.write(row, 7, data['net_amount'], centered)
            worksheet.write(row, 8, len(data['pending_students']), centered)
            worksheet.write(row, 9, data['pending_amount'], centered)
            worksheet.write(row, 10, data['received_amount'], centered)

            # Sum for total row
            totals[2] += student_count
            totals[3] += len(data['paying_full'])
            totals[4] += actual_fee_total
            totals[5] += on_concession
            totals[6] += data['concession_amount']
            totals[7] += data['net_amount']
            totals[8] += len(data['pending_students'])
            totals[9] += data['pending_amount']
            totals[10] += data['received_amount']

            row += 1
            serial += 1

        # Write total row
        worksheet.write(row, 1, "Total", bold_centered)
        for col in range(2, len(headers)):
            worksheet.write(row, col, totals[col], bold_centered)

        # Adjust column width
        worksheet.set_column('A:A', 5)
        worksheet.set_column('B:B', 20)
        worksheet.set_column('C:J', 15)

        # Concession Summary Table (After the first table)

        # Move to the next row for the new table
        row += 3  # Add some space after the first table

        # Add Headers for Concession Summary Table
        summary_headers = [
            "Concession Percent", "Count of Students", "Sum of Actual Amount",
            "Receivable Amount", "Concession Amount"
        ]
        worksheet.write_row(row, 0, summary_headers, bold_centered)  # Concession Summary Table Header

        # Get All Invoices (Filtered by Date Range)
        invoices = self.env['account.move'].sudo().search([
            ('state', '=', 'posted'),
            ('invoice_date_due', '>=', start_date),
            ('invoice_date_due', '<=', end_date),
            ('branch_id', '=', branch_id.id)
        ])

        # Initialize Concession Categories
        concession_categories = [100, 75, 50, 25, 0]  # Concession percentages

        # Dictionary to Track Data by Concession Percent
        concession_data = {percent: {'students': set(), 'receivable_amount': 0} for percent in concession_categories}

        # Process Each Invoice
        for inv in invoices:
            concession_percent = inv.concession_percent or 0

            # Only include known categories
            if concession_percent not in concession_categories:
                continue

            # Update Concession Data
            concession_data[concession_percent]['students'].add(inv.partner_id.id)
            concession_data[concession_percent]['receivable_amount'] += inv.amount_total

        # Initialize Totals
        total_students = total_actual = total_receivable = total_concession = 0

        # Write Data to Excel
        summary_row = row + 1  # Start the data rows after the header

        for concession_percent in concession_categories:
            data = concession_data[concession_percent]
            student_count = len(data['students'])
            sum_actual_amount = sum([
                inv.actual_fee for inv in invoices
                if (inv.concession_percent or 0) == concession_percent
            ])
            receivable_amount = data['receivable_amount']
            concession_amount = sum_actual_amount - receivable_amount

            # Write Data to Excel
            worksheet.write(summary_row, 0, f"{concession_percent}%", centered)
            worksheet.write(summary_row, 1, student_count, centered)
            worksheet.write(summary_row, 2, sum_actual_amount, centered)
            worksheet.write(summary_row, 3, receivable_amount, centered)
            worksheet.write(summary_row, 4, concession_amount, centered)

            # Update Totals
            total_students += student_count
            total_actual += sum_actual_amount
            total_receivable += receivable_amount
            total_concession += concession_amount

            summary_row += 1

        # Add Total Row at the End
        worksheet.write(summary_row, 0, "Total", bold_centered)
        worksheet.write(summary_row, 1, total_students, bold_centered)
        worksheet.write(summary_row, 2, total_actual, bold_centered)
        worksheet.write(summary_row, 3, total_receivable, bold_centered)
        worksheet.write(summary_row, 4, total_concession, bold_centered)

        # Adjust Column Width for the Summary Table
        worksheet.set_column('A:A', 20)
        worksheet.set_column('B:E', 18)

