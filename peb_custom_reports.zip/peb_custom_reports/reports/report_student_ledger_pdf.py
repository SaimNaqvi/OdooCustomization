from odoo import models, fields
from datetime import datetime


class ReportStudentLedgerPDF(models.AbstractModel):
    _name = 'report.peb_custom_reports.student_ledger_report_pdf'
    _description = 'Student Ledger Report PDF'
    _inherit = 'report.report_xlsx.abstract'

    def _get_report_values(self, docids, data=None):
        wizard = self.env['wizard.report.student.ledger'].browse(docids)

        # Get Student Info
        student_name = wizard.student_name.name
        student_code = wizard.student_code
        branch_names = ', '.join(wizard.branch_ids.mapped('name'))

        # Fetch invoice records
        invoices = self._fetch_invoice_records(wizard)
        invoices.sort(key=lambda r: (
            int(r.get('fee_year', 0)),
            self._class_sort_key(r.get('current_grade', 'Unknown')),
            int(r.get('fee_month_number', 0))
        ))

        prev_class = None
        prev_year = None
        year_total = 0
        class_total = 0
        yearly_totals = {}

        structured_data = []

        for invoice in invoices:
            fee_year = invoice['fee_year']
            class_name = invoice['current_grade']

            # If class changes or year changes, add class total
            if prev_class and (prev_class != class_name or prev_year != fee_year):
                structured_data.append({
                    'type': 'class_total',
                    'fee_year': prev_year,
                    'current_grade': prev_class,
                    'total': class_total
                })
                class_total = 0  # Reset class total

            # If year changes, add year total
            if prev_year and prev_year != fee_year:
                structured_data.append({
                    'type': 'year_total',
                    'fee_year': prev_year,
                    'total': year_total
                })
                year_total = 0  # Reset yearly total

            # Add invoice record
            structured_data.append(invoice)

            # Update totals
            class_total += invoice['total_bill']
            year_total += invoice['total_bill']
            yearly_totals[fee_year] = yearly_totals.get(fee_year, 0) + invoice['total_bill']

            prev_class = class_name
            prev_year = fee_year

        # Final Class Total
        if prev_class:
            structured_data.append({
                'type': 'class_total',
                'fee_year': prev_year,
                'current_grade': prev_class,
                'total': class_total
            })

        # Final Year Total
        if prev_year:
            structured_data.append({
                'type': 'year_total',
                'fee_year': prev_year,
                'total': year_total
            })

        return {
            'doc_ids': docids,
            'doc_model': 'wizard.report.student.ledger',
            'docs': [wizard],
            'student_name': student_name,
            'student_code': student_code,
            'branch_name': branch_names,
            'invoices': structured_data,
        }

    def _fetch_invoice_records(self, wizard):
        domain = [('state', '=', 'posted'), ('move_type', '=', 'out_invoice')]

        start_date = wizard.start_date or '2014-01-01'
        end_date = wizard.end_date or fields.Date.today()
        domain += [
            ('invoice_date_due', '>=', start_date),
            ('invoice_date_due', '<=', end_date),
        ]
        if wizard.branch_ids:
            domain.append(('branch_id', 'in', wizard.branch_ids.ids))

        if wizard.student_code:
            domain.append(('partner_id.student_code', '=', wizard.student_code))
        elif wizard.student_name:
            domain.append(('partner_id.student_code', '=', wizard.student_name.student_code))

        invoices = self.env['account.move'].sudo().search(domain)
        records = []

        for invoice in invoices:
            fee_year = invoice.invoice_date_due.year if invoice.invoice_date_due else ''
            fee_month = invoice.invoice_date_due.month if invoice.invoice_date_due else 1
            class_name = invoice.x_studio_grade or 'Unknown'

            records.append({
                'type': 'invoice',
                'current_grade': class_name,
                'fee_year': fee_year,
                'fee_month': datetime(2000, fee_month, 1).strftime('%B'),
                'bill_number': invoice.name or '',
                'received_date': invoice.ol_payment_date.strftime('%d-%b-%y') if invoice.ol_payment_date else '',
                'fee_month_number': fee_month,
                'due_date': invoice.invoice_date_due.strftime('%d-%b-%y') if invoice.invoice_date_due else '',
                'total_bill': invoice.amount_total or 0.0,
            })

        return records

    def _class_sort_key(self, class_name):
        predefined_classes = {'Nur': 0, 'Prep': 1}
        class_name = class_name.strip().capitalize()
        if class_name in predefined_classes:
            return predefined_classes[class_name]
        if class_name.isdigit():
            return int(class_name)
        return 100
