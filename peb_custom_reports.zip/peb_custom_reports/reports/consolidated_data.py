from odoo import models
import logging
from datetime import datetime  # Import datetime module to get the current date

_logger = logging.getLogger(__name__)

class ConsolidatedDataXlsx(models.AbstractModel):
    _name = 'report.peb_custom_reports.report_consolidated_data_xlsx'
    _inherit = 'report.report_xlsx.abstract'

    def generate_xlsx_report(self, workbook, data, wizard):
        # Define formats for title, headers, and data
        title_format = workbook.add_format({
            'bold': True,
            'border': 1,  # Adds a border around the cell
            'font_size': 18,
            'font_name': 'Arial',
            'align': 'center',
            'valign': 'vcenter',
            'bg_color': '#4F81BD',
            'font_color': 'white',
        })

        header_format = workbook.add_format({
            'bold': True,
            'font_size': 12,
            'font_name': 'Arial',
            'align': 'center',
            'valign': 'vcenter',
            'bg_color': '#9CC3E6',
            'font_color': 'black',
        })

        title_data_format = workbook.add_format({
            'border': 1,
            'valign': 'vcenter',
            'align': 'center',
            'font_size': 12,
            'font_name': 'Arial',
            'bg_color': '#E1F5FE',
        })

        side_heading_format = workbook.add_format({
            'border': 1,
            'bold': True,
            'font_size': 12,
            'font_name': 'Arial',
            'align': 'center',
            'valign': 'vcenter',
            'bg_color': '#F2F2F2',
            'font_color': 'black',
        })

        sky_blue_format = workbook.add_format({
            'bold': True,
            'font_size': 12,
            'font_name': 'Arial',
            'align': 'center',
            'valign': 'vcenter',
            'bg_color': '#87CEEB',  # Sky blue color
            'font_color': 'black',
        })

        empty_space_format = workbook.add_format({
            'bg_color': '#E1F5FE',  # Light blue color (can be changed as required)
            'border': 1,  # Adds a border around the cell
        })

        # Ensure sheet is initialized properly
        sheet = workbook.add_worksheet('Consolidated Data')

        # Merging and applying format to various ranges
        sheet.merge_range('F8:M8', '', header_format)  # F8 to M8 is colored now
        sheet.merge_range('F9:M9', '', title_data_format)  # F9 to M9 is colored now
        sheet.merge_range('N4:O4', '', header_format)  # N4 to O4 is colored now
        sheet.merge_range('N6:O6', '', empty_space_format)  # N6 to O6 is colored now


        # Get current month and year
        current_month_year = datetime.now().strftime("%B %Y")

        # # Create a new worksheet
        # sheet = workbook.add_worksheet('Consolidated Data')

        # Set column widths
        sheet.set_column('A:A', 30)  # Wide enough for titles and categories
        sheet.set_column('B:B', 15)  # Christian Boys/Girls columns
        sheet.set_column('C:C', 15)
        sheet.set_column('D:D', 15)  # Muslim Boys/Girls columns
        sheet.set_column('E:E', 15)
        sheet.set_column('F:F', 15)  # Sikh Boys/Girls columns
        sheet.set_column('G:G', 15)
        sheet.set_column('H:H', 15)  # No Religion Boys/Girls columns
        sheet.set_column('I:I', 15)
        sheet.set_column('J:J', 15)  # Total count column

        # Merge and format title
        # Merge and format title, adjusting for a wider range
        sheet.merge_range('A1:O1', 'Kinnard Academy High School for Girls', title_format)
        sheet.merge_range('A2:O2', f'Student and Staff Consolidated Data - {current_month_year}', header_format)

        # Get selected branch and student data
        selected_branch = wizard.branch_id
        students_domain = [('branch_id', '=', selected_branch.id), ('is_student', '=', True)]
        students = self.env['res.partner'].search(students_domain)

        # Calculate counts for each religion (Christian, Muslim, Sikh, No Religion, Hindu, Ahmadi)
        christian_girls = len(students.filtered(lambda p: p.religion == 'Christian' and p.gender == 'female'))
        christian_boys = len(students.filtered(lambda p: p.religion == 'Christian' and p.gender == 'male'))
        muslim_girls = len(students.filtered(lambda p: p.religion == 'Islam' and p.gender == 'female'))
        muslim_boys = len(students.filtered(lambda p: p.religion == 'Islam' and p.gender == 'male'))
        sikh_girls = len(students.filtered(lambda p: p.religion == 'sikh' and p.gender == 'female'))
        sikh_boys = len(students.filtered(lambda p: p.religion == 'sikh' and p.gender == 'male'))
        hindu_girls = len(students.filtered(lambda p: p.religion == 'hindu' and p.gender == 'female'))
        hindu_boys = len(students.filtered(lambda p: p.religion == 'hindu' and p.gender == 'male'))
        ahmadi_girls = len(students.filtered(lambda p: p.religion == 'Ahmadi' and p.gender == 'female'))
        ahmadi_boys = len(students.filtered(lambda p: p.religion == 'Ahmadi' and p.gender == 'male'))
        no_religion_girls = len(students.filtered(lambda p: p.religion == 'No Religion' and p.gender == 'female'))
        no_religion_boys = len(students.filtered(lambda p: p.religion == 'No Religion' and p.gender == 'male'))

        # Add headers for student data
        sheet.write('A3', 'Students', header_format)
        sheet.merge_range('B3:C3', 'Christian', header_format)
        sheet.merge_range('D3:E3', 'Muslim', header_format)
        sheet.merge_range('F3:G3', 'Sikh', header_format)
        sheet.merge_range('H3:I3', 'Hindu', header_format)
        sheet.merge_range('J3:K3', 'Ahmadi', header_format)
        sheet.merge_range('L3:M3', 'No Religion', header_format)
        sheet.merge_range('N3:O3', 'Total', header_format)
        sheet.write('B4', 'Girls', header_format)
        sheet.write('C4', 'Boys', header_format)
        sheet.write('D4', 'Girls', header_format)
        sheet.write('E4', 'Boys', header_format)
        sheet.write('F4', 'Girls', header_format)
        sheet.write('G4', 'Boys', header_format)
        sheet.write('H4', 'Girls', header_format)
        sheet.write('I4', 'Boys', header_format)
        sheet.write('J4', 'Girls', header_format)
        sheet.write('K4', 'Boys', header_format)
        sheet.write('L4', 'Girls', header_format)
        sheet.write('M4', 'Boys', header_format)

        # Write student data counts
        sheet.write('B5', christian_girls, title_data_format)
        sheet.write('C5', christian_boys, title_data_format)
        sheet.write('D5', muslim_girls, title_data_format)
        sheet.write('E5', muslim_boys, title_data_format)
        sheet.write('F5', sikh_girls, title_data_format)
        sheet.write('G5', sikh_boys, title_data_format)
        sheet.write('H5', hindu_girls, title_data_format)
        sheet.write('I5', hindu_boys, title_data_format)
        sheet.write('J5', ahmadi_girls, title_data_format)
        sheet.write('K5', ahmadi_boys, title_data_format)
        sheet.write('L5', no_religion_girls, title_data_format)
        sheet.write('M5', no_religion_boys, title_data_format)


        # Total count for all students
        total_students = christian_girls + christian_boys + muslim_girls + muslim_boys + sikh_girls + sikh_boys + hindu_girls+ hindu_boys + ahmadi_girls + ahmadi_boys+ no_religion_girls + no_religion_boys
        sheet.merge_range('N5:O5', total_students, title_data_format)


        # Add total row for boys and girls counts
        sheet.merge_range('B6:C6', '=B5+C5', title_data_format)
        sheet.merge_range('D6:E6', '=D5+E5', title_data_format)
        sheet.merge_range('F6:G6', '=F5+G5', title_data_format)
        sheet.merge_range('H6:I6', '=H5+I5', title_data_format)
        sheet.merge_range('J6:K6', '=J5+K5', title_data_format)
        sheet.merge_range('L6:M6', '=L5+M5', title_data_format)


        # Add second set of column headers for total students
        sheet.write('A8', 'Total Students', header_format)
        sheet.merge_range('B8:C8', 'Boys', header_format)
        sheet.merge_range('D8:E8', 'Girls', header_format)
        sheet.merge_range('N8:O8', 'Total', header_format)

        sheet.merge_range('B9:C9', christian_boys + muslim_boys + sikh_boys + ahmadi_boys + hindu_boys + no_religion_boys, title_data_format)
        sheet.merge_range('D9:E9', christian_girls + muslim_girls + sikh_girls + ahmadi_girls + hindu_girls +no_religion_girls, title_data_format)
        sheet.merge_range('N9:O9', '=SUM(B9:E9)', title_data_format)

        # Add staff table headers
        sheet.write('A11', 'Staff', header_format)
        sheet.merge_range('B11:C11', 'Christian', header_format)
        sheet.merge_range('D11:E11', 'Muslim', header_format)
        sheet.merge_range('F11:G11', 'Sikh', header_format)
        sheet.merge_range('H11:I11', 'Hindu', header_format)
        sheet.merge_range('J11:K11', 'Ahmadi', header_format)
        sheet.merge_range('L11:M11', 'No Religion', header_format)
        sheet.merge_range('N11:O11', 'Total', header_format)

        # Filter staff data based on branch
        staff_domain = [('branch_id', '=', selected_branch.id), ('title', '=', 'Staff')]
        staff = self.env['res.partner'].search(staff_domain)

        # Staff categories
        staff_categories = [
            ('Principal / V. Principal / Admin', 'Admin/Principal / V. Principal'),
            ('Teachers', 'Teacher'),
            ('Band Master', 'Band_master'),
            ('Lab assistant', 'Lab_Assistant'),
            ('Accountant', 'Accountant'),
        ]

        # Loop through staff categories and add rows
        row = 12
        for category, staff_title in staff_categories:
            christian_staff = len(staff.filtered(lambda p: p.religion == 'Christian' and p.staff_title == staff_title))
            muslim_staff = len(staff.filtered(lambda p: p.religion == 'Muslim' and p.staff_title == staff_title))
            sikh_staff = len(staff.filtered(lambda p: p.religion == 'sikh' and p.staff_title == staff_title))
            hindu_staff = len(staff.filtered(lambda p: p.religion == 'hindu' and p.staff_title == staff_title))
            ahmadi_staff = len(staff.filtered(lambda p: p.religion == 'Ahmadi' and p.staff_title == staff_title))
            no_religion_staff = len(staff.filtered(lambda p: p.religion == 'No Religion' and p.staff_title == staff_title))

            # Write the category in the first column
            sheet.write(f'A{row}', category, side_heading_format)

            # Write the individual counts (without merging the same ranges)
            sheet.merge_range(f'B{row}:C{row}', christian_staff, title_data_format)
            sheet.merge_range(f'D{row}:E{row}', muslim_staff, title_data_format)
            sheet.merge_range(f'F{row}:G{row}', sikh_staff, title_data_format)
            sheet.merge_range(f'H{row}:I{row}', hindu_staff, title_data_format)
            sheet.merge_range(f'J{row}:K{row}', ahmadi_staff, title_data_format)
            sheet.merge_range(f'L{row}:M{row}', no_religion_staff, title_data_format)

            # Write the sum for all categories in the merged cell
            sheet.merge_range(f'N{row}:O{row}',
                              christian_staff + muslim_staff + sikh_staff + hindu_staff + ahmadi_staff + no_religion_staff,
                              title_data_format)

            row += 1

        # Assuming 'row' is the variable holding the current row number
        sheet.write(f'A{row}', 'Total Teachers/Admin', sky_blue_format)

        # Merge the two boxes for each religious category sum and apply sum formulas
        sheet.merge_range(f'B{row}:C{row}', '=SUM(B12:B16)', title_data_format)  # Christian
        sheet.merge_range(f'D{row}:E{row}', '=SUM(D12:D16)', title_data_format)  # Muslim
        sheet.merge_range(f'F{row}:G{row}', '=SUM(F12:F16)', title_data_format)  # Sikh
        sheet.merge_range(f'H{row}:I{row}', '=SUM(H12:H16)', title_data_format)  # Hindu
        sheet.merge_range(f'J{row}:K{row}', '=SUM(J12:J16)', title_data_format)  # Ahmadi
        sheet.merge_range(f'L{row}:M{row}', '=SUM(L12:L16)', title_data_format)  # No Religion

        # Merge the two columns for total sum of teachers/admin
        sheet.merge_range(f'N{row}:O{row}', '=SUM(N12:N16)', title_data_format)

        row += 4

        # Add Support Staff Section
        sheet.write('A18', 'Support Staff', header_format)

        support_staff_categories = [
            ('Office Attendant', 'Office_attendant'),
            ('Gardener', 'Gardener'),
            ('Cleaner', 'Cleaner'),
            ('Security Guard', 'Security_Guard'),
            ('Company Guard (Day)', 'Company_guard_day'),
            ('Company Guard (Night)', 'Security_Guard(Night)'),
        ]

        row = 19  # Starting row for support staff data
        for category, staff_title in support_staff_categories:
            christian_support = len(
                staff.filtered(lambda p: p.religion == 'Christian' and p.staff_title == staff_title))
            muslim_support = len(staff.filtered(lambda p: p.religion == 'Muslim' and p.staff_title == staff_title))
            sikh_support = len(staff.filtered(lambda p: p.religion == 'sikh' and p.staff_title == staff_title))
            hindu_support = len(staff.filtered(lambda p: p.religion == 'hindu' and p.staff_title == staff_title))
            ahmadi_support = len(staff.filtered(lambda p: p.religion == 'ahmadi' and p.staff_title == staff_title))
            no_religion_support = len(staff.filtered(
                lambda p: p.religion == 'No Religion' and p.staff_title == staff_title))  # Added No Religion

            # Write category name
            sheet.write(f'A{row}', category, side_heading_format)

            # Write the count for Christian, Muslim, Sikh, Hindu, Ahmadi, and No Religion (Support staff)
            sheet.merge_range(f'B{row}:C{row}', christian_support, title_data_format)
            sheet.merge_range(f'D{row}:E{row}', muslim_support, title_data_format)
            sheet.merge_range(f'F{row}:G{row}', sikh_support, title_data_format)
            sheet.merge_range(f'H{row}:I{row}', hindu_support, title_data_format)  # Hindu support
            sheet.merge_range(f'J{row}:K{row}', ahmadi_support, title_data_format)  # Ahmadi support
            sheet.merge_range(f'L{row}:M{row}', no_religion_support, title_data_format)  # No Religion support

            # Write the total for this category
            sheet.merge_range(f'N{row}:O{row}',
                              christian_support + muslim_support + sikh_support + hindu_support + ahmadi_support + no_religion_support,
                              title_data_format)

            row += 1

        # Corrected SUM formulas to add the correct ranges
        sheet.merge_range(f'B{row}:C{row}', '=SUM(B12:B16)', title_data_format)
        sheet.merge_range(f'D{row}:E{row}', '=SUM(D12:D16)', title_data_format)
        sheet.merge_range(f'F{row}:G{row}', '=SUM(F12:F16)', title_data_format)
        sheet.merge_range(f'H{row}:I{row}', '=SUM(H12:H16)', title_data_format)
        sheet.merge_range(f'J{row}:K{row}', '=SUM(J12:J16)', title_data_format)

        # Separate merging for different sums
        sheet.merge_range(f'L{row}:M{row}', '=SUM(L12:L16)', title_data_format)
        sheet.merge_range(f'N{row}:O{row}', '=SUM(N12:N16)', title_data_format)

        # Grand Total Calculation for Students
        # Grand Total Calculation for Students
        total_students = christian_girls + christian_boys + muslim_girls + muslim_boys + sikh_girls + sikh_boys + hindu_girls + hindu_boys + ahmadi_girls + ahmadi_boys + no_religion_girls + no_religion_boys

        # Grand Total Calculation for Staff
        total_christian_staff = sum(
            len(staff.filtered(lambda p: p.religion == 'Christian' and p.staff_title == staff_title)) for
            category, staff_title in staff_categories)
        total_muslim_staff = sum(
            len(staff.filtered(lambda p: p.religion == 'Muslim' and p.staff_title == staff_title)) for
            category, staff_title in staff_categories)
        total_sikh_staff = sum(
            len(staff.filtered(lambda p: p.religion == 'Sikh' and p.staff_title == staff_title)) for
            category, staff_title in staff_categories)
        total_hindu_staff = sum(
            len(staff.filtered(lambda p: p.religion == 'Hindu' and p.staff_title == staff_title)) for
            category, staff_title in staff_categories)
        total_ahmadi_staff = sum(
            len(staff.filtered(lambda p: p.religion == 'Ahmadi' and p.staff_title == staff_title)) for
            category, staff_title in staff_categories)
        total_no_religion_staff = sum(
            len(staff.filtered(lambda p: p.religion == 'No Religion' and p.staff_title == staff_title)) for
            category, staff_title in staff_categories)

        # Total Staff (combined Christian, Muslim, Sikh, Hindu, Ahmadi, No Religion)
        total_staff = total_christian_staff + total_muslim_staff + total_sikh_staff + total_hindu_staff + total_ahmadi_staff + total_no_religion_staff

        # Grand Total (Students + Staff)
        grand_total = total_students + total_staff

        # Write Grand Total for Students and Staff
        row += 2  # Add space after the last entry (adjust as needed)

        # Final Grand Total Row (Students + Staff)
        sheet.write(f'A{row}', 'Total AT KA', sky_blue_format)  # Title "Total AT KA" (or other as needed)

        # Grand Total (Students + Staff)
        sheet.merge_range(f'B{row}:O{row}', grand_total, title_data_format)  # Grand Total (Students + Staff)
