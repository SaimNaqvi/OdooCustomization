from odoo import models, fields
import xlsxwriter
from collections import defaultdict
from dateutil.relativedelta import relativedelta


class WizardClassWiseFeePendingReport(models.AbstractModel):
    _name = 'report.peb_custom_reports.report_class_wise_fee_pending_xlsx'
    _inherit = 'report.report_xlsx.abstract'

    def generate_xlsx_report(self, workbook, data, wizard):
        bold_centered = workbook.add_format({'bold': True, 'align': 'center', 'border': 1})
        centered = workbook.add_format({'align': 'center', 'border': 1})
        title_format = workbook.add_format({'bold': True, 'font_size': 14, 'align': 'center', 'border': 1})
        header_format = workbook.add_format({'bold': True, 'align': 'center', 'font_size': 16, 'border': 1})

        ALL_MONTHS = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec']

        branch_ids = wizard.branch_id.ids
        start_date = wizard.start_date
        end_date = wizard.end_date

        if not start_date or not end_date:
            raise ValueError("Start Date and End Date must be provided.")

        start_year = start_date.strftime('%Y')
        formatted_end_date = end_date.strftime('%m/%d/%Y')

        months_in_range = []
        current_date = start_date
        while current_date <= end_date:
            months_in_range.append(current_date.strftime('%b'))
            current_date += relativedelta(months=1)

        for branch_id in branch_ids:
            branch = self.env['res.branch'].browse(branch_id)
            branch_name = branch.name

            sheet = workbook.add_worksheet(f'Class Wise Fee Pending - {branch_name}')
            sheet.merge_range('B1:O1', 'Summary of Fee Defaulters / Pending Class-wise', header_format)
            sheet.merge_range('B2:O2', f'For the Year - {start_year} Not Received Till {formatted_end_date}', title_format)
            sheet.merge_range('A3:O3', f'Branch: {branch_name}', header_format)

            sub_headers = ['S.No', 'Class Section'] + ALL_MONTHS + ['Total']
            sheet.write_row('A4', sub_headers, header_format)

            row_idx = 5

            domain = [
                ('branch_id', '=', branch_id),
                ('invoice_date_due', '>=', start_date),
                ('invoice_date_due', '<=', end_date),
                ('state', '=', 'posted'),
                ('payment_state', '=', 'not_paid'),
            ]

            if wizard.religion:
                domain.append(('partner_id.religion', '=', wizard.religion))
            if wizard.gender:
                domain.append(('partner_id.gender', '=', wizard.gender))
            if wizard.concessions:
                domain.append(('concession_percent', '=', wizard.concessions))
            if wizard.classes:
                domain.append(('x_studio_grade', '=', wizard.classes.name))
            if wizard.active:
                domain.append(('partner_id.current_enroll_status', '=', 'Enrolled'))

            invoices = self.env['account.move'].sudo().search(domain)

            class_fees = defaultdict(lambda: {
                'section': '',
                'monthly_fees': defaultdict(float),
                'total_fees': 0,
            })
            total_monthly_fees = defaultdict(float)

            predefined_classes = ['nur', 'prep'] + [str(i) for i in range(1, 11)]
            for cls in predefined_classes:
                class_fees[cls]

            for inv in invoices:
                if inv.invoice_date_due:
                    month_name = inv.invoice_date_due.strftime('%b')
                    if month_name in months_in_range:
                        amount = inv.amount_residual

                        # Normalize class name
                        class_name = (inv.x_studio_grade or '').strip().lower()
                        homeroom = inv.partner_id.new_homeroom or ''

                        if class_name in ['nursery', 'nur']:
                            class_name = 'nur'
                        elif class_name in ['prep', 'preparatory']:
                            class_name = 'prep'

                        class_fees[class_name]['section'] = homeroom
                        class_fees[class_name]['monthly_fees'][month_name] += amount
                        class_fees[class_name]['total_fees'] += amount
                        total_monthly_fees[month_name] += amount

            serial_no = 1
            grand_totals = [0] * 12

            for class_name in predefined_classes:
                fees = class_fees[class_name]
                sheet.write(row_idx, 0, serial_no, centered)

                formatted_class_name = class_name.capitalize() if class_name in ['nur', 'prep'] else class_name
                class_section = f"{formatted_class_name} - {fees['section']}" if fees['section'] else formatted_class_name
                sheet.write(row_idx, 1, class_section, bold_centered if class_name in ['nur', 'prep'] else centered)

                for i, month_name in enumerate(ALL_MONTHS):
                    fee = fees['monthly_fees'].get(month_name, 0)
                    if month_name in months_in_range:
                        sheet.write(row_idx, i + 2, int(fee) if fee > 0 else '', centered)
                    else:
                        sheet.write(row_idx, i + 2, '', centered)

                    grand_totals[i] += fee

                total_fee = fees['total_fees']
                sheet.write(row_idx, 14, int(total_fee) if total_fee > 0 else '', centered)
                row_idx += 1
                serial_no += 1

            sheet.write(row_idx, 1, "School Total", bold_centered)
            for i, total in enumerate(grand_totals):
                sheet.write(row_idx, i + 2, int(total) if total > 0 else '', bold_centered)

            sheet.write(row_idx, 14, sum(grand_totals), bold_centered)

