from odoo import models, fields, _
from datetime import datetime
from dateutil.relativedelta import relativedelta


class FeeDefaulterReportXlsx(models.AbstractModel):
    _name = 'report.peb_custom_reports.fee_defaulter_xlsx'
    _inherit = 'report.report_xlsx.abstract'

    def generate_xlsx_report(self, workbook, data, wizard):
        sheet = workbook.add_worksheet('Fee Defaulters')

        # Formats
        bold_centered = workbook.add_format({'bold': True, 'align': 'left', 'border': 1, 'font_size': 16})
        centered = workbook.add_format({'align': 'center', 'border': 1})
        left_aligned = workbook.add_format({'align': 'left', 'border': 1})
        date_format = workbook.add_format({'num_format': 'dd/mm/yyyy', 'align': 'center', 'border': 1})
        title_format = workbook.add_format({'bold': True, 'font_size': 14, 'align': 'left', 'border': 2})
        currency_format = workbook.add_format({'num_format': '0', 'align': 'center', 'border': 1})
        month_heading_format = workbook.add_format(
            {'bold': True, 'font_size': 12, 'align': 'center', 'bg_color': '#D3D3D3', 'border': 1})
        class_heading_format = workbook.add_format(
            {'bold': True, 'font_size': 11, 'align': 'center', 'bg_color': '#E8E8E8', 'border': 1})
        subheader_format = workbook.add_format({'bold': True, 'align': 'center', 'border': 1, 'bg_color': '#F5F5F5'})

        # Fetch data from wizard
        branch = wizard.branch
        start_date = wizard.start_date
        end_date = wizard.end_date
        till_date = wizard.till_date or fields.Date.today()
        classes = wizard.classes
        concessions = wizard.concessions
        branch_ids = branch.ids
        branch_names = ', '.join(branch.mapped('name'))

        # Adjust end_date based on till_date
        if till_date and till_date <= end_date:
            end_date = till_date

        # Format report title
        start_str = start_date.strftime('%d-%m-%Y') if start_date else ''
        end_str = end_date.strftime('%d-%m-%Y') if end_date else ''
        till_str = till_date.strftime('%d-%m-%Y')
        report_title = f"Fee Defaulter Report for {start_str}, {end_str} Till date ({till_str})"
        sheet.merge_range('A1:G1', report_title, title_format)
        sheet.merge_range('A2:G2', f"Branch: {branch_names}", title_format)

        # Define domain for invoices
        domain = [
            ('state', '=', 'posted'),
            ('invoice_date', '>=', start_date),
            ('invoice_date', '<=', end_date),
            ('branch_id', 'in', branch_ids),
        ]

        # Apply filter based on active, adopted, or employees status
        if wizard.active:
            domain.append(('partner_id.active', '=', True))  # Filtering for active students
        elif wizard.adopted:
            domain.append(('partner_id.donor_name', '=', 'donor'))  # Filtering for adopted students (donor)
        elif wizard.employees:
            domain.append(('partner_id.employee', '=', True))  # Filtering for employee children
        if concessions:
            domain.append(('concession_percent', '=', concessions))
        if wizard.gender:
            domain.append(('partner_id.gender', '=', wizard.gender))
        if wizard.religion:
            domain.append(('partner_id.religion', '=', wizard.religion))

        if classes:  # If classes are selected in the wizard
            class_names = classes.mapped('name')
            domain.append(('x_studio_grade', 'in', class_names))  # Use class names to filter

        if till_date:
            domain += [('invoice_date_due', '<', till_date),
                       '|',
                       ('ol_payment_date', '=', False),
                       ('ol_payment_date', '>', till_date)]

        invoices = self.env['account.move'].sudo().search(domain)

        # Custom sorting function for classes
        # Custom sorting function for classes
        def class_sort_key(class_name):
            predefined_classes = {'nur': 0, 'prep': 1}

            if class_name.lower() in predefined_classes:
                return (predefined_classes[class_name.lower()],)
            elif class_name.isdigit():
                return (2, int(class_name))
            else:
                return (3, class_name.lower())

        # Group invoices by month and class
        month_class_data = {}
        for inv in invoices:
            month_year = inv.invoice_date_due.strftime('%b %Y')
            student_class = inv.x_studio_grade or 'No Class'
            month_class_data.setdefault(month_year, {}).setdefault(student_class, []).append(inv)

        # Write data to sheet
        row = 4
        grand_total_students, grand_total_fees = 0, 0
        sorted_months = sorted(month_class_data.keys(), key=lambda x: datetime.strptime(x, '%b %Y'))

        for month_year in sorted_months:
            if not month_class_data[month_year]:
                continue
            sheet.merge_range(row, 0, row, 6, month_year, month_heading_format)
            row += 1

            sorted_classes = sorted(month_class_data[month_year].items(), key=lambda x: class_sort_key(x[0]))
            for class_name, inv_list in sorted_classes:
                sheet.merge_range(row, 0, row, 6, f"Class: {class_name}", class_heading_format)
                row += 1
                sheet.write_row(row, 0, ['Sr#', 'Name', 'Student Code', 'Class', 'Bill #', 'Due Date', 'Total'],
                                subheader_format)
                row += 1

                class_total_fees = 0
                for i, inv in enumerate(sorted(inv_list, key=lambda inv: inv.partner_id.name or ''), start=1):
                    sheet.write(row, 0, i, centered)
                    sheet.write(row, 1, inv.partner_id.name or '', left_aligned)
                    sheet.write(row, 2, inv.partner_id.student_code or '', centered)
                    sheet.write(row, 3, class_name, centered)
                    sheet.write(row, 4, inv.name or '', centered)
                    sheet.write(row, 5, inv.invoice_date_due.strftime('%d-%m-%Y') if inv.invoice_date_due else '',
                                date_format)
                    sheet.write(row, 6, inv.amount_total or 0.0, currency_format)
                    row += 1
                    grand_total_students += 1
                    class_total_fees += inv.amount_total or 0.0
                    grand_total_fees += inv.amount_total or 0.0

                sheet.write(row, 1, f'Total of Class {class_name}', bold_centered)
                sheet.write(row, 6, class_total_fees, currency_format)
                row += 1

        sheet.merge_range(row + 2, 0, row + 2, 6,
                          f"Total of {branch_names}: {grand_total_students} Fee Vouchers Pending: Rs. {grand_total_fees}",
                          bold_centered)
        sheet.set_column('A:G', 15)
