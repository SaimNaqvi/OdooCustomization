from odoo import models, fields
from datetime import datetime, timedelta
import logging

_logger = logging.getLogger(__name__)


class FeeNotReceivedPDF(models.AbstractModel):
    _name = 'report.peb_custom_reports.report_fee_not_received_pdf'
    _description = 'Fee Not Received Report PDF'
    _inherit = 'report.report_xlsx.abstract'

    def _get_report_values(self, docids, data=None):
        _logger.info(f"Received data in _get_report_values: {data}")

        if not data or 'form' not in data:
            raise ValueError("Missing wizard data.")

        wizard_data = data.get('form')
        wizard = self.env['wizard.fee.not.received.report'].browse(wizard_data.get('id'))

        if not wizard.exists():
            raise ValueError("Wizard record not found.")

        branch_ids = wizard.branch_id  # List of selected branch IDs
        start_date = wizard.start_date
        end_date = wizard.end_date
        concessions = wizard.concessions
        religion = wizard.religion
        gender = wizard.gender
        classes = wizard.classes

        report_data = []
        grand_total = 0

        # Iterate over each branch selected in the wizard
        for branch in branch_ids:
            branch_data = {
                'branch_name': branch.name if branch else 'No Branch',
                'start_date': start_date.strftime('%B %d, %Y'),
                'end_date': end_date.strftime('%B %d, %Y'),
                'months': [],
                'total_yearly_unpaid': 0
            }

            current_date = start_date
            while current_date <= end_date:
                month_start = current_date.replace(day=1)
                month_end = self._get_month_end(current_date.year, current_date.month)

                # Define the domain to filter invoices based on the criteria
                domain = [
                    ('branch_id', '=', branch.ids),  # Corrected this line to use branch.id
                    ('state', '=', 'posted'),
                    ('invoice_date_due', '>=', month_start),
                    ('invoice_date_due', '<=', month_end),
                    ('payment_state', 'not in', ['paid', 'in_payment'])
                ]

                # Apply additional filters if they are set in the wizard
                if religion:
                    domain.append(('partner_id.religion', '=', religion))
                if gender:
                    domain.append(('partner_id.gender', '=', gender))
                if concessions:
                    domain.append(('concession_percent', '=', concessions))
                if classes:
                    class_names = classes.mapped('name')
                    if class_names:
                        domain.append(('x_studio_grade', 'in', class_names))

                # Fetch the invoices based on the domain filter
                invoices = self.env['account.move'].sudo().search(domain)
                total_unpaid = sum(inv.amount_total for inv in invoices) if invoices else 0
                branch_data['total_yearly_unpaid'] += total_unpaid
                grand_total += total_unpaid

                # Add the monthly data to the report for the branch
                month_name = datetime(current_date.year, current_date.month, 1).strftime('%b %Y')
                branch_data['months'].append({
                    'month_name': month_name,
                    'unpaid_total': total_unpaid
                })

                # Move to the next month
                next_month = current_date.replace(day=28) + timedelta(days=4)
                current_date = next_month.replace(day=1)

            # Add the data for the current branch to the final report data
            report_data.append(branch_data)

        # Ensure at least an empty entry to prevent template errors in case no data is found
        if not report_data:
            report_data.append({'branch_name': 'No Data', 'months': [], 'total_yearly_unpaid': 0})

        return {
            'doc_ids': docids,
            'doc_model': 'wizard.fee.not.received.report',
            'data': data,
            'report_data': report_data,
            'grand_total': grand_total,
            'start_date': start_date.strftime('%B %d, %Y'),
            'end_date': end_date.strftime('%B %d, %Y'),
        }

    def _get_month_end(self, year, month):
        """Returns the last day of the given month."""
        if month == 12:
            return datetime(year, month, 31)
        next_month = datetime(year, month + 1, 1)
        return next_month - timedelta(days=1)
