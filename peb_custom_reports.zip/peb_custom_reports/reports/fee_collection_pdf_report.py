from odoo import models, fields, api
from datetime import date, datetime
import calendar


class ReportFeeCollectionPDF(models.AbstractModel):
    _name = 'report.peb_custom_reports.report_fee_collection_pdf'
    _description = 'Total Fee Collection PDF Report'

    def _get_report_values(self, docids, data=None):
        wizard = self.env['fee.collection.report.wizard'].browse(docids)
        start_date = wizard.start_date
        end_date = wizard.end_date
        branch_ids = wizard.branch_id.ids

        domain = [
            ('branch_id', 'in', branch_ids),
            ('invoice_date_due', '>=', start_date),
            ('invoice_date_due', '<=', end_date),
            ('state', '=', 'posted')
        ]

        if wizard.religion:
            domain.append(('partner_id.religion', '=', wizard.religion))
        if wizard.gender:
            domain.append(('partner_id.gender', '=', wizard.gender))
        if wizard.concessions:
            domain.append(('concession_percent', '=', wizard.concessions))
        if wizard.classes:
            class_names = wizard.classes.mapped('name')
            domain.append(('x_studio_grade', 'in', [name.lower() for name in class_names]))
        if wizard.active:
            domain.append(('partner_id.current_enroll_status', '=', 'Enrolled'))

        invoices = self.env['account.move'].sudo().search(domain)
        invoices_by_class = {}
        all_fee_types = set()

        for inv in invoices:
            class_name = (inv.x_studio_grade or 'Unknown Class').lower()
            invoices_by_class.setdefault(class_name, []).append(inv)
            for line in inv.invoice_line_ids:
                all_fee_types.add(line.product_id.name)

        dynamic_fee_types = sorted(all_fee_types)
        if 'Tuition Fee' in dynamic_fee_types:
            dynamic_fee_types.remove('Tuition Fee')

        def class_sort_key(name):
            key_map = {'nur': 0, 'prep': 1}
            if name.lower() in key_map:
                return (key_map[name.lower()],)
            if name.isdigit():
                return (2, int(name))
            return (3, name.lower())

        sorted_class_names = sorted(invoices_by_class.keys(), key=class_sort_key)

        report_data = []
        current_date = start_date
        while current_date <= end_date:
            month = calendar.month_name[current_date.month]
            year = current_date.year
            month_data = []

            for class_name in sorted_class_names:
                class_invoices = [inv for inv in invoices_by_class[class_name]
                                  if inv.invoice_date_due.month == current_date.month and
                                  inv.invoice_date_due.year == current_date.year]

                if not class_invoices:
                    continue

                class_summary = {
                    'class_name': class_name.capitalize(),
                    'month': month,
                    'year': year,
                    'students': [],
                    'totals': {},
                    'pending_amount': 0,
                    'received_amount': 0,
                    'total_students': len(class_invoices),
                }

                actual_fee_total = 0
                pending_students = 0
                for idx, inv in enumerate(sorted(class_invoices, key=lambda i: i.partner_id.name), start=1):
                    student = inv.partner_id
                    fee_lines = {l.product_id.name: l.price_subtotal for l in inv.invoice_line_ids}
                    tuition_fee = fee_lines.get('Tuition Fee', 0)
                    actual_fee = inv.actual_fee
                    actual_fee_total += actual_fee

                    total_fee = sum(l.price_subtotal for l in inv.invoice_line_ids)
                    late_fee = sum(l.price_subtotal for l in inv.invoice_line_ids if 'late fee' in l.name.lower())
                    admission_fee = sum(
                        l.price_subtotal for l in inv.invoice_line_ids if 'admission fee' in l.name.lower())
                    adjusted_fee = total_fee - late_fee - admission_fee
                    concession_amount = actual_fee - adjusted_fee
                    E = concession_amount + tuition_fee
                    concession_percent = (concession_amount * 100 / E) if E else 0
                    inv.concession_percent = concession_percent

                    receive_date = inv.ol_payment_date_compute.strftime(
                        '%d-%B-%Y') if inv.ol_payment_date_compute else ''

                    row_data = {
                        'sr': idx,
                        'reg': student.student_code or '',
                        'roll': student.roll_no or '',
                        'name': student.name or '',
                        'actual_fee': int(actual_fee) if actual_fee else '',
                        'bill_no': inv.name or '',
                        'receive_date': receive_date,
                        'tuition_fee': int(tuition_fee) if tuition_fee else '',
                        'concession_percent': round(concession_percent, 2),
                        'dynamic_fees': {},
                        'total': int(inv.amount_total) if inv.amount_total else ''
                    }

                    for fee_type in dynamic_fee_types:
                        fee_val = fee_lines.get(fee_type, 0)
                        row_data['dynamic_fees'][fee_type] = int(fee_val) if fee_val else ''

                    class_summary['students'].append(row_data)

                    for fee_type in dynamic_fee_types:
                        class_summary['totals'].setdefault(fee_type, 0)
                        if fee_type in fee_lines:
                            class_summary['totals'][fee_type] += fee_lines[fee_type]

                    if inv.ol_payment_date_compute:
                        class_summary['received_amount'] += inv.amount_total
                    else:
                        class_summary['pending_amount'] += inv.amount_total
                        pending_students += 1

                class_summary['actual_fee_total'] = actual_fee_total
                class_summary['pending_students'] = pending_students

                # Add Total Row
                total_row = {
                    'sr': '',
                    'reg': '',
                    'roll': '',
                    'name': 'Total',
                    'actual_fee': int(sum(s['actual_fee'] or 0 for s in class_summary['students'])) or '',
                    'bill_no': '',
                    'receive_date': '',
                    'tuition_fee': int(sum(s['tuition_fee'] or 0 for s in class_summary['students'])) or '',
                    'concession_percent': '',
                    'dynamic_fees': {},
                    'total': int(sum(s['total'] or 0 for s in class_summary['students'])) or ''
                }

                for fee_type in dynamic_fee_types:
                    fee_sum = sum(s['dynamic_fees'].get(fee_type, 0) or 0 for s in class_summary['students'])
                    total_row['dynamic_fees'][fee_type] = int(fee_sum) if fee_sum else ''

                class_summary['students'].append(total_row)

                month_data.append(class_summary)

            report_data.append({
                'month': month,
                'year': year,
                'classes': month_data,
            })

            # Move to next month
            if current_date.month == 12:
                current_date = current_date.replace(year=current_date.year + 1, month=1, day=1)
            else:
                current_date = current_date.replace(month=current_date.month + 1, day=1)

        return {
            'doc_ids': docids,
            'doc_model': 'fee.collection.report.wizard',
            'data': data,
            'wizard': wizard,
            'report_data': report_data,
            'dynamic_fee_types': dynamic_fee_types,
            'branch_names': ', '.join(wizard.branch_id.mapped('name')),
        }
