from odoo import models, fields
from datetime import datetime


class FeeDefaulterPDF(models.AbstractModel):
    _name = 'report.peb_custom_reports.report_student_name_list_pdf'
    _description = 'Student Name List PDF'
    _inherit = 'report.report_xlsx.abstract'

    def _get_report_values(self, docids, data=None):
        wizard = self.env['student.name.list.wizard'].browse(docids)
        branches = wizard.branch_id
        if not branches:
            return {}
        def format_date(date):
            suffix = 'th'
            if 4 <= date.day <= 20:
                suffix = 'th'
            else:
                suffix = {1: 'st', 2: 'nd', 3: 'rd'}.get(date.day % 10, 'th')
            return f"{date.day}{suffix} {date.strftime('%B %Y')}"

        start_date_formatted = format_date(wizard.start_date)
        end_date_formatted = format_date(wizard.end_date)

        domain = [
            ('state', '=', 'posted'),
            ('invoice_date_due', '>=', wizard.start_date),
            ('invoice_date_due', '<=', wizard.end_date),
        ]

        if branches:
            domain.append(('branch_id', 'in', branches.ids))
        if wizard.religion:
            domain.append(('partner_id.religion', '=', wizard.religion))
        if wizard.gender:
            domain.append(('partner_id.gender', '=', wizard.gender))
        if wizard.concessions:
            domain.append(('concession_percent', '=', wizard.concessions))
        if wizard.active:
            domain.append(('partner_id.current_enroll_status', '=', 'Enrolled'))
        if wizard.classes:
            class_names = wizard.classes.mapped('name')
            domain.append(('x_studio_grade', 'in', class_names))

        invoices = self.env['account.move'].sudo().search(domain)

        unique_students = {}
        for invoice in invoices:
            student = invoice.partner_id
            if student and student.id not in unique_students:
                unique_students[student.id] = invoice

        grouped_students = {}
        for invoice in unique_students.values():
            class_name = invoice.x_studio_grade or 'Unknown'
            grouped_students.setdefault(class_name, []).append(invoice)

        def class_sort_key(class_name):
            predefined_classes = {'nur': 0, 'prep': 1}
            if class_name.lower() in predefined_classes:
                return (predefined_classes[class_name.lower()],)
            if class_name.isdigit():
                return (2, int(class_name))
            return (3, class_name.lower())

        sorted_class_names = sorted(grouped_students.keys(), key=class_sort_key)

        docs = []

        for class_name in sorted_class_names:
            sorted_students = sorted(grouped_students[class_name], key=lambda s: s.partner_id.name.lower())
            for invoice in sorted_students:
                student = invoice.partner_id
                student_code = student.student_code or ''
                roll_no = student.reg_number or ''
                student_name = student.name or ''
                father_name = next((rel.parent_id.name for rel in student.student_relationship_ids if
                                    rel.relationship_type == 'father'), '')
                current_enroll_status = student.current_enroll_status.name if student.current_enroll_status else ''
                display_class_name = 'Nur' if class_name.lower() == 'nur' else 'Prep' if class_name.lower() == 'prep' else class_name

                concession_percentage = invoice.concession_percent or 0

                # Get Tuition Fee from invoice lines
                tuition_fee = 0
                for line in invoice.invoice_line_ids:
                    if line.product_id.name == 'Tuition Fee':
                        tuition_fee = line.price_total
                        break

                docs.append({
                    'student_code': student_code,
                    'roll_no': roll_no,
                    'display_class_name': display_class_name,
                    'student_name': student_name,
                    'father_name': father_name,
                    'concessions': concession_percentage,
                    'current_enroll_status': current_enroll_status,
                    'tuition_fee': tuition_fee,
                    'total_fee': invoice.amount_total,
                    'concession_percentage': concession_percentage,
                })

        return {
            'doc_ids': docids,
            'doc_model': 'student.name.list.wizard',
            'docs': docs,
            'branches': branches,
            'start_date': start_date_formatted,
            'end_date': end_date_formatted,
            'o': wizard
        }

