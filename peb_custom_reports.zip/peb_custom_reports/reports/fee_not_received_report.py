from odoo import models, fields
from datetime import datetime, timedelta
import logging

_logger = logging.getLogger(__name__)


class FeeNotReceivedReportXlsx(models.AbstractModel):
    _name = 'report.peb_custom_reports.report_fee_not_received_xlsx'
    _inherit = 'report.report_xlsx.abstract'

    def generate_xlsx_report(self, workbook, data, wizard):
        sheet = workbook.add_worksheet('Fee Not Received')

        header_format = workbook.add_format({'border': 1, 'bold': True, 'align': 'center', 'valign': 'vcenter'})
        branch_format = workbook.add_format({'border': 1, 'bold': True, 'font_size': 14, 'align': 'center'})
        summary_format = workbook.add_format({'border': 1, 'bold': True, 'align': 'center', 'valign': 'vcenter'})
        numeric_format = workbook.add_format({'border': 1, 'align': 'center', 'valign': 'vcenter', 'num_format': '0'})

        branch_ids = wizard.branch_id
        start_date = wizard.start_date
        end_date = wizard.end_date
        concessions = wizard.concessions
        religion = wizard.religion
        gender = wizard.gender
        classes = wizard.classes

        row = 0

        # Precompute all month names for the entire range
        current_date = start_date
        month_names = []
        while current_date <= end_date:
            month_name = current_date.strftime('%b %Y')
            month_names.append(month_name)
            next_month = current_date.replace(day=28) + timedelta(days=4)
            current_date = next_month.replace(day=1)

        month_totals = [0] * len(month_names)
        final_grand_total = 0

        for branch in branch_ids:
            branch_name = branch.name if branch else 'No Branch'
            sheet.merge_range(row, 0, row, 7, f"Branch: {branch_name}", branch_format)

            start_date_str = start_date.strftime('%B %d, %Y')
            end_date_str = end_date.strftime('%B %d, %Y')
            sheet.merge_range(row + 1, 0, row + 1, 7,
                              f"Summary of Fee Not Received from {start_date_str} to {end_date_str}", summary_format)

            sheet.write(row + 3, 1, "Month", header_format)
            sheet.write_row(row + 3, 2, month_names, header_format)
            sheet.write(row + 4, 1, "Amount", header_format)

            unpaid_totals = []
            current_date = start_date
            total_yearly_unpaid = 0
            month_index = 0

            while current_date <= end_date:
                month_start = current_date.replace(day=1)
                month_end = FeeNotReceivedReportXlsx._get_month_end(current_date.year, current_date.month)

                domain = [
                    ('branch_id', '=', branch.id),
                    ('state', '=', 'posted'),
                    ('invoice_date_due', '>=', month_start),
                    ('invoice_date_due', '<=', month_end),
                    ('payment_state', 'not in', ['paid', 'in_payment']),
                ]
                if religion:
                    domain.append(('partner_id.religion', '=', religion))
                if gender:
                    domain.append(('partner_id.gender', '=', gender))
                if concessions:
                    domain.append(('partner_id.student_concessions.concession_type', '=', concessions))
                if classes:
                    class_names = classes.mapped('name')
                    if class_names:
                        domain.append(('x_studio_grade', 'in', class_names))

                invoices = self.env['account.move'].sudo().search(domain)
                total_unpaid = sum(inv.amount_total for inv in invoices)
                unpaid_totals.append(total_unpaid)
                total_yearly_unpaid += total_unpaid

                month_totals[month_index] += total_unpaid
                month_index += 1

                next_month = current_date.replace(day=28) + timedelta(days=4)
                current_date = next_month.replace(day=1)

            final_grand_total += total_yearly_unpaid
            sheet.write_row(row + 4, 2, unpaid_totals, numeric_format)
            sheet.write(row + 4, len(month_names) + 2, total_yearly_unpaid, numeric_format)
            sheet.write(row + 3, len(month_names) + 2, "Total", header_format)

            sheet.set_column('B:B', 20)
            for col in range(len(month_names) + 3):
                sheet.set_column(col + 1, col + 1, 10)

            row += 6

        # Write grand totals row
        sheet.write(row, 1, "Grand Total", header_format)
        sheet.write_row(row, 2, month_totals, numeric_format)
        sheet.write(row, len(month_names) + 2, final_grand_total, numeric_format)

    @staticmethod
    def _get_month_end(year, month):
        if month == 12:
            return datetime(year, month, 31)
        next_month = datetime(year, month + 1, 1)
        return next_month - timedelta(days=1)
