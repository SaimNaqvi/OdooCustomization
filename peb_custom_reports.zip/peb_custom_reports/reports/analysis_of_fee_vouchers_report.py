from odoo import models
from datetime import datetime, timedelta
import logging

_logger = logging.getLogger(__name__)


class AnalysisOfFeeVouchersXlsx(models.AbstractModel):
    _name = 'report.peb_custom_reports.report_analysis_of_fee_vouchers_xlsx'
    _inherit = 'report.report_xlsx.abstract'

    def generate_xlsx_report(self, workbook, data, wizard):
        if not wizard or not data:
            raise ValueError("Wizard or data is missing.")

        branch_ids = wizard.branch_ids.ids
        start_date = wizard.start_date
        end_date = wizard.end_date

        # Month labels
        month_data = []
        current_month = start_date.replace(day=1)
        while current_month <= end_date:
            month_data.append(current_month.strftime('%b'))
            next_month = current_month.replace(day=28) + timedelta(days=4)
            current_month = next_month.replace(day=1)

        branches = self.env['res.branch'].sudo().search([('id', 'in', branch_ids)])
        boarding_branches = [b for b in branches if 'BOARDING' in b.name.upper()]
        school_branches = [b for b in branches if 'BOARDING' not in b.name.upper()]

        all_categories = ['fee_generated', 'collected', 'pending', 'bills_generated', 'collected_now', 'pending_now']
        summary_data = {
            'hostel': {month: {cat: 0 for cat in all_categories} for month in month_data},
            'school': {month: {cat: 0 for cat in all_categories} for month in month_data},
            'grand': {month: {cat: 0 for cat in all_categories} for month in month_data}
        }

        sheet = workbook.add_worksheet('Fee Vouchers')
        title_format = workbook.add_format({'bold': True, 'font_size': 16, 'align': 'center'})
        subtitle_format = workbook.add_format({'bold': True, 'font_size': 14, 'align': 'center'})
        numeric_format = workbook.add_format({'border': 1, 'valign': 'vcenter', 'num_format': '0', 'align': 'center'})
        total_format = workbook.add_format({'bold': True, 'align': 'center'})
        left_format = workbook.add_format({'bold': True, 'align': 'left'})

        # New bordered formats for totals
        bordered_total_format = workbook.add_format({
            'bold': True, 'align': 'center', 'valign': 'vcenter', 'border': 1
        })
        bordered_numeric_format = workbook.add_format({
            'align': 'center', 'valign': 'vcenter', 'num_format': '0', 'border': 1
        })
        # orange_format = workbook.add_format({'bold': True, 'bg_color': '#FCE4D6', 'align': 'center'})

        sheet.merge_range(0, 0, 0, len(month_data) + 1, "Analysis of Fee Vouchers", title_format)
        sheet.merge_range(1, 0, 1, len(month_data) + 1,
                          f"From {start_date.strftime('%d-%b-%Y')} to {end_date.strftime('%d-%b-%Y')}", subtitle_format)

        current_row = 3

        def process_branch(branch, is_hostel):
            nonlocal current_row
            sheet.merge_range(current_row, 0, current_row, len(month_data) + 1, f"{branch.name}", left_format)
            current_row += 1
            sheet.write_row(current_row, 1, month_data + ['Total'], total_format)
            current_row += 1

            monthly_summary = {month: {cat: 0 for cat in all_categories} for month in month_data}
            domain = [
                ('branch_id', '=', branch.id),
                ('invoice_date_due', '>=', start_date),
                ('invoice_date_due', '<=', end_date),
                ('state', '=', 'posted')
            ]
            invoices = self.env['account.move'].sudo().search(domain)

            for invoice in invoices:
                month = invoice.invoice_date_due.strftime('%b')
                if month not in month_data:
                    continue
                monthly_summary[month]['fee_generated'] += invoice.amount_total
                monthly_summary[month]['bills_generated'] += 1
                if invoice.payment_state in ['in_payment', 'paid']:
                    monthly_summary[month]['collected'] += invoice.amount_total
                    monthly_summary[month]['collected_now'] += 1
                else:
                    monthly_summary[month]['pending'] += invoice.amount_total
                    monthly_summary[month]['pending_now'] += 1

            for cat in all_categories:
                row_data = [cat.replace('_', ' ').title()]
                for month in month_data:
                    row_data.append(monthly_summary[month][cat])
                    section = 'hostel' if is_hostel else 'school'
                    summary_data[section][month][cat] += monthly_summary[month][cat]
                    summary_data['grand'][month][cat] += monthly_summary[month][cat]
                total = sum(monthly_summary[month][cat] for month in month_data)
                row_data.append(total)
                current_row = self.write_row(sheet, current_row, row_data, numeric_format)
                # current_row = self.write_row(sheet, current_row, row_data, orange_format)

            current_row += 1

        for branch in boarding_branches:
            process_branch(branch, is_hostel=True)

        def write_section_totals(section_name, section_key):
            nonlocal current_row
            titles = [
                f'{section_name} Total Fee Generated :',
                'Total Collected :',
                'Total Pending :',
                f'{section_name} Total Bills Generated :',
                'Total Collected :',
                'Total Pending :',
            ]
            keys = ['fee_generated', 'collected', 'pending', 'bills_generated', 'collected_now', 'pending_now']

            for title, key in zip(titles, keys):
                row_data = [title]
                for month in month_data:
                    row_data.append(summary_data[section_key][month][key])
                total = sum(summary_data[section_key][month][key] for month in month_data)
                row_data.append(total)
                current_row = self.write_row(sheet, current_row, row_data, bordered_numeric_format)
                sheet.write(current_row - 1, 0, title, bordered_total_format)

            current_row += 1

        write_section_totals('Hostels', 'hostel')

        for branch in school_branches:
            process_branch(branch, is_hostel=False)

        write_section_totals('Schools', 'school')
        write_section_totals('Grand Total', 'grand')

        sheet.set_column('A:A', 30)
        for col in range(1, len(month_data) + 2):
            sheet.set_column(col, col, 14)

    def write_row(self, sheet, row_idx, data, cell_format):
        sheet.write_row(row_idx, 0, data, cell_format)
        return row_idx + 1