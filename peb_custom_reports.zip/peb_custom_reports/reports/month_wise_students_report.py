from calendar import monthrange
from odoo import models, fields
from datetime import datetime
from collections import defaultdict


class MonthWiseStudentsReportXlsx(models.AbstractModel):
    _name = 'report.peb_custom_reports.report_month_wise_students_xlsx'
    _inherit = 'report.report_xlsx.abstract'

    def generate_xlsx_report(self, workbook, data, wizard):
        # Initialize worksheet
        sheet = workbook.add_worksheet('Month Wise Students Report')

        # Define formatting styles
        header_format = workbook.add_format({'border': 1, 'bold': True, 'align': 'center', 'valign': 'vcenter'})
        branch_format = workbook.add_format({'border': 1, 'bold': True, 'font_size': 10, 'align': 'center'})
        bold_centered = workbook.add_format({'bold': True, 'align': 'center', 'border': 1})
        total_format = workbook.add_format({'border': 1, 'align': 'center'})
        class_total_format = workbook.add_format({'border': 1, 'bold': True, 'align': 'center'})
        grand_total_format = workbook.add_format({'border': 1, 'bold': True, 'align': 'center', 'bg_color': '#D3D3D3'})

        # Month-to-number mapping
        month_map = {
            'January': 1, 'February': 2, 'March': 3, 'April': 4, 'May': 5, 'June': 6,
            'July': 7, 'August': 8, 'September': 9, 'October': 10, 'November': 11, 'December': 12
        }

        # Extract month and year from the wizard data
        month_name = dict(wizard._fields['month'].selection).get(wizard.month)  # This is the month name
        year = wizard.year

        # Convert the month name to a number
        if month_name not in month_map:
            raise ValueError(f"Invalid month name: {month_name}")
        month = month_map[month_name]  # Convert month name to the corresponding number

        first_day_of_month = datetime(year, month, 1)

        # Top Heading: School Name (with thinner formatting)
        sheet.merge_range('A1:M1', 'KINNAIRD ACADEMY HIGH SCHOOL FOR GIRLS', branch_format)

        # Reduce row height for the heading to make it thinner
        sheet.set_row(0, 20)

        # Space between main heading and sub-heading
        sheet.write('B2', '', header_format)

        # Second Main Heading: Student Record
        sheet.merge_range('A3:M3', f'Student Record - As of {month_name} {year}', branch_format)

        # Sub Heading Section for the detailed report
        sheet.write('A5', 'Class', bold_centered)
        sheet.write('B5', 'Section', bold_centered)
        sheet.write('C5', 'Total Strength at the Beginning of the Month', bold_centered)
        sheet.write('D5', 'New Admission During the Month', bold_centered)
        sheet.write('E5', 'Withdrawal During the Month', bold_centered)
        sheet.write('F5', 'Total Strength', bold_centered)

        # Section for Religious Breakdown
        sheet.write('G5', 'Christian Boys', bold_centered)
        sheet.write('H5', 'Christian Girls', bold_centered)
        sheet.write('I5', 'Christian Total', bold_centered)
        sheet.write('J5', 'Muslim Boys', bold_centered)
        sheet.write('K5', 'Muslim Girls', bold_centered)
        sheet.write('L5', 'Muslim Total', bold_centered)
        sheet.write('M5', 'Total Students', bold_centered)

        # ---- Data Section: Students Data Fetching and Aggregation ----

        # Data Fetching and Aggregation
        students = self._fetch_students_for_report(month, year)

        # For storing report data based on class-section
        report_data = defaultdict(lambda: {'Christian': {'Boys': 0, 'Girls': 0},
                                           'Islam': {'Boys': 0, 'Girls': 0}})

        # For tracking students' withdrawals, admissions, and registrations
        withdrawal_data = defaultdict(int)
        admission_data = defaultdict(int)
        registration_data = defaultdict(int)
        enrolled_data = defaultdict(lambda: defaultdict(int))  # Nested defaultdict to store per-class-section data

        # Process Students to aggregate their data
        for student in students:
            self.enrollment_history(student, month, year, withdrawal_data, admission_data, registration_data,
                                    enrolled_data)

            # Class, Section, and Religion data
            class_section = self._get_class_section(student)
            gender = self._get_gender(student)
            religion = self._get_religion(student)

            if religion in report_data[class_section]:
                report_data[class_section][religion][gender] += 1

        # Custom sorting for classes and homerooms
        sorted_sections = self._sort_sections(report_data)

        # Writing Data to Sheet
        row = 6  # Start writing data from row 6, after the sub-heading
        previous_class = None
        # Initialize class-wise data for each class-section
        class_wise_boys_total = {'Christian': 0, 'Islam': 0}
        class_wise_girls_total = {'Christian': 0, 'Islam': 0}
        class_wise_total_strength = 0

        grand_boys_total = {'Christian': 0, 'Islam': 0}
        grand_girls_total = {'Christian': 0, 'Islam': 0}

        for class_section in sorted_sections:
            current_class, section = class_section.split('-')

            if current_class != previous_class and previous_class is not None:
                # Add class-wise total row
                self._write_class_total_row(sheet, row, previous_class, class_wise_boys_total, class_wise_girls_total,
                                            class_wise_total_strength, class_total_format)
                row += 1  # Move to the next row
                class_wise_boys_total = {'Christian': 0, 'Islam': 0}
                class_wise_girls_total = {'Christian': 0, 'Islam': 0}
                class_wise_total_strength = 0

            # Get the student data
            religions = report_data[class_section]
            total_strength_beginning = enrolled_data.get(class_section, {}).get('total', 0)
            new_admission_this_month = admission_data.get(student.id, 0)  # Get the admission count for this student
            withdrawals_this_month = withdrawal_data.get(class_section, 0)

            # Total Strength = Total Strength at the Beginning of the Month - Withdrawals
            total_strength = total_strength_beginning - withdrawals_this_month

            # Calculate the class-section totals
            christian_boys = religions['Christian']['Boys']
            christian_girls = religions['Christian']['Girls']
            muslim_boys = religions['Islam']['Boys']
            muslim_girls = religions['Islam']['Girls']

            total_students = christian_boys + christian_girls + muslim_boys + muslim_girls - withdrawals_this_month

            # Update the class-wise totals
            class_wise_boys_total['Christian'] += christian_boys
            class_wise_girls_total['Christian'] += christian_girls
            class_wise_boys_total['Islam'] += muslim_boys
            class_wise_girls_total['Islam'] += muslim_girls
            class_wise_total_strength += total_students

            # Update grand totals
            grand_boys_total['Christian'] += christian_boys
            grand_girls_total['Christian'] += christian_girls
            grand_boys_total['Islam'] += muslim_boys
            grand_girls_total['Islam'] += muslim_girls

            # Write the student data into the row
            self._write_student_row(sheet, row, current_class, section, total_strength_beginning,
                                    new_admission_this_month, withdrawals_this_month,
                                    christian_boys, christian_girls, christian_boys + christian_girls,
                                    muslim_boys, muslim_girls, muslim_boys + muslim_girls,
                                    total_students, total_format)

            row += 1  # Move to the next row
            previous_class = current_class

        # Add Final Total Row
        self._write_grand_total_row(sheet, row, grand_boys_total, grand_girls_total, grand_total_format)

    def generate_xlsx_report(self, workbook, data, wizard):
        # Initialize worksheet
        sheet = workbook.add_worksheet('Month Wise Students Report')

        # Define formatting styles
        header_format = workbook.add_format({'border': 1, 'bold': True, 'align': 'center', 'valign': 'vcenter'})
        branch_format = workbook.add_format({'border': 1, 'bold': True, 'font_size': 10, 'align': 'center'})
        bold_centered = workbook.add_format({'bold': True, 'align': 'center', 'border': 1})
        total_format = workbook.add_format({'border': 1, 'align': 'center'})
        class_total_format = workbook.add_format({'border': 1, 'bold': True, 'align': 'center'})
        grand_total_format = workbook.add_format({'border': 1, 'bold': True, 'align': 'center', 'bg_color': '#D3D3D3'})

        # Month-to-number mapping
        month_map = {
            'January': 1, 'February': 2, 'March': 3, 'April': 4, 'May': 5, 'June': 6,
            'July': 7, 'August': 8, 'September': 9, 'October': 10, 'November': 11, 'December': 12
        }

        # Extract month and year from the wizard data
        month_name = dict(wizard._fields['month'].selection).get(wizard.month)  # This is the month name
        year = wizard.year

        if month_name not in month_map:
            raise ValueError(f"Invalid month name: {month_name}")
        month = month_map[month_name]  # Convert month name to the corresponding number

        first_day_of_month = datetime(year, month, 1)

        # Top Heading: School Name (with thinner formatting)
        sheet.merge_range('A1:M1', 'KINNAIRD ACADEMY HIGH SCHOOL FOR GIRLS', branch_format)

        # Space between main heading and sub-heading
        sheet.write('B2', '', header_format)

        # Second Main Heading: Student Record
        sheet.merge_range('A3:M3', f'Student Record - As of {month_name} {year}', branch_format)

        # Sub Heading Section for the detailed report
        sheet.write('A5', 'Class', bold_centered)
        sheet.write('B5', 'Section', bold_centered)
        sheet.write('C5', 'Total Strength at the Beginning of the Month', bold_centered)
        sheet.write('D5', 'New Admission During the Month', bold_centered)
        sheet.write('E5', 'Withdrawal During the Month', bold_centered)
        sheet.write('F5', 'Total Strength', bold_centered)

        # Section for Religious Breakdown
        sheet.write('G5', 'Christian Boys', bold_centered)
        sheet.write('H5', 'Christian Girls', bold_centered)
        sheet.write('I5', 'Christian Total', bold_centered)
        sheet.write('J5', 'Muslim Boys', bold_centered)
        sheet.write('K5', 'Muslim Girls', bold_centered)
        sheet.write('L5', 'Muslim Total', bold_centered)
        sheet.write('M5', 'Total Students', bold_centered)

        # ---- Data Section: Students Data Fetching and Aggregation ----

        # Data Fetching and Aggregation (Only new admissions)
        students = self._fetch_students_for_report(month, year)

        # For tracking new admissions
        admission_data = defaultdict(int)  # Only track admissions
        withdrawal_data = defaultdict(int)  # Track withdrawals (if needed)
        registration_data = defaultdict(int)
        enrolled_data = defaultdict(lambda: defaultdict(int))  # Nested defaultdict to store per-class-section data


        # For storing report data based on class-section
        report_data = defaultdict(lambda: {'Christian': {'Boys': 0, 'Girls': 0}, 'Islam': {'Boys': 0, 'Girls': 0}})

        # Process Students to aggregate their data
        for student in students:
            self.enrollment_history(student, month, year, withdrawal_data, admission_data, {}, {})

            # Class, Section, and Religion data
            class_section = self._get_class_section(student)
            gender = self._get_gender(student)
            religion = self._get_religion(student)

            if religion in report_data[class_section]:
                report_data[class_section][religion][gender] += 1

        # Custom sorting for classes and homerooms
        sorted_sections = self._sort_sections(report_data)

        # Writing Data to Sheet
        row = 6  # Start writing data from row 6
        previous_class = None

        # Initialize class-wise data for each class-section
        class_wise_boys_total = {'Christian': 0, 'Islam': 0}
        class_wise_girls_total = {'Christian': 0, 'Islam': 0}
        class_wise_total_strength = 0

        grand_boys_total = {'Christian': 0, 'Islam': 0}
        grand_girls_total = {'Christian': 0, 'Islam': 0}

        for class_section in sorted_sections:
            current_class, section = class_section.split('-')

            if current_class != previous_class and previous_class is not None:
                # Add class-wise total row
                self._write_class_total_row(sheet, row, previous_class, class_wise_boys_total, class_wise_girls_total,
                                            class_wise_total_strength, class_total_format)
                row += 1
                class_wise_boys_total = {'Christian': 0, 'Islam': 0}
                class_wise_girls_total = {'Christian': 0, 'Islam': 0}
                class_wise_total_strength = 0

            # Get the student data
            religions = report_data[class_section]
            total_strength_beginning = 0  # This is where you'd calculate the beginning strength, if necessary
            new_admission_this_month = admission_data.get(class_section, 0)
            withdrawals_this_month = withdrawal_data.get(class_section, 0)

            # Total Strength = Total Strength at the Beginning of the Month - Withdrawals
            total_strength = total_strength_beginning - withdrawals_this_month

            # Calculate the class-section totals
            christian_boys = religions['Christian']['Boys']
            christian_girls = religions['Christian']['Girls']
            muslim_boys = religions['Islam']['Boys']
            muslim_girls = religions['Islam']['Girls']

            total_students = christian_boys + christian_girls + muslim_boys + muslim_girls

            # Update the class-wise totals
            class_wise_boys_total['Christian'] += christian_boys
            class_wise_girls_total['Christian'] += christian_girls
            class_wise_boys_total['Islam'] += muslim_boys
            class_wise_girls_total['Islam'] += muslim_girls
            class_wise_total_strength += total_students

            # Update grand totals
            grand_boys_total['Christian'] += christian_boys
            grand_girls_total['Christian'] += christian_girls
            grand_boys_total['Islam'] += muslim_boys
            grand_girls_total['Islam'] += muslim_girls

            # Write the student data into the row
            self._write_student_row(sheet, row, current_class, section, total_strength_beginning,
                                    new_admission_this_month, withdrawals_this_month, christian_boys, christian_girls,
                                    christian_boys + christian_girls, muslim_boys, muslim_girls,
                                    muslim_boys + muslim_girls,
                                    total_students, total_format)

            row += 1  # Move to the next row
            previous_class = current_class

        # Add Final Total Row
        self._write_grand_total_row(sheet, row, grand_boys_total, grand_girls_total, grand_total_format)

    def _fetch_students_for_report(self, month, year):
        """Fetch the students for the specified month and year."""
        students = self.env['res.partner'].search([('is_student', '=', True),
                                                   ('title', '=', 'Student'),
                                                   ('branch_id.name', '=', 'KINNAIRD ACADEMY HIGH SCHOOL FOR GIRLS')])
        return students or []  # Ensure it returns a list, even if no students are found

    def enrollment_history(self, student, month, year, withdrawal_data, admission_data, registration_data,
                           enrolled_data):
        """Process each student's enrollment history to count those still enrolled on the 1st of the month and new admissions."""

        # Calculate the first and last days of the month
        first_day_of_month = datetime(year, month, 1).date()  # Date representing the 1st of the month
        last_day_of_month = datetime(year, month, monthrange(year, month)[1]).date()  # Last day of the month

        # # Ensure that 'enrolled_data' is initialized as a defaultdict to avoid key errors
        # if isinstance(enrolled_data):
        #     pass  # Already using defaultdict, no need to change
        # else:
        #     enrolled_data = defaultdict(
        #         lambda: {'beginning_strength': 0, 'new_admissions': 0, 'total': 0})  # Initialize

        # Ensure class_section is defined and valid
        class_section = self._get_class_section(student)
        if 'False' in class_section:
            class_section = class_section.replace('False', 'Unknown')

        # Initialize enrolled_data for class_section if not already present
        if class_section not in enrolled_data:
            enrolled_data[class_section] = {'beginning_strength': 0, 'new_admissions': 0, 'total': 0}  # Initialize

        # Track students admitted on or before the 1st of the month (for beginning strength)
        for history in student.enrollment_histories_ids:
            if not history.date or not history.status:
                continue  # Skip invalid records

            history_date = history.date.date() if isinstance(history.date, datetime) else history.date

            # 1. Track students with status "Enrolled" or "Admissions" for the beginning of the month
            # Check if the history date is before the 1st of the month (for actions before the start of the month)
            if history.date < first_day_of_month:
                if history.status == 'enroll':  # Check if the action was 'register'
                    enrolled_data[student.id] += 1

        # Track new admissions during the current month (from 1st to the last day of the month)
        for history in student.enrollment_histories_ids:
            if not history.date or not history.status:
                continue  # Skip invalid records

            history_date = history.date.date() if isinstance(history.date, datetime) else history.date

            # 2. Track new admissions during the current month (from 1st to the last day of the month)
            if first_day_of_month <= history_date <= last_day_of_month:
                if history.status == 'Admissions':
                    admission_data[class_section] += 1  # Increment admissions for the class-section
                    enrolled_data[class_section]['new_admissions'] += 1  # Increment new admissions for the class-section

        # Calculate total strength at the beginning of the month
        enrolled_data[class_section]['total'] = enrolled_data[class_section]['beginning_strength'] + \
                                                enrolled_data[class_section]['new_admissions']

        # 3. Track Withdrawals during the month
        if history.status == 'Withdrawn':
            withdrawal_data[class_section] += 1  # Track withdrawals for the class-section

            # Count total enrollments, including transfers or re-enrollments during the month
            enrolled_data[class_section]['total'] += 1  # Update total strength for the class-section

            # After processing all histories, ensure the total strength at the beginning of the month is tracked correctly
        enrolled_data[class_section]['total'] += enrolled_data[class_section]['beginning_strength']

        # Optionally, return the enrolled data
        return enrolled_data

    def _get_class_section(self, student):
        """Determine the class and section of the student."""
        return f"{student.current_grade_selection}-{student.new_homeroom}"

    def _get_gender(self, student):
        """Return the gender of the student."""
        return 'Boys' if student.gender == 'male' else 'Girls'

    def _get_religion(self, student):
        """Return the religion of the student."""
        return student.religion

    def _sort_sections(self, report_data):
        """Sort the class-section data as needed."""
        return sorted(report_data.keys())

    def _write_student_row(self, sheet, row, class_name, section, total_strength_beginning,
                           new_admission_this_month, withdrawals_this_month,
                           christian_boys, christian_girls, christian_total,
                           muslim_boys, muslim_girls, muslim_total,
                           total_students, total_format):
        """Write each student row of data."""
        sheet.write(row, 0, class_name, total_format)
        sheet.write(row, 1, section, total_format)
        sheet.write(row, 2, total_strength_beginning, total_format)
        sheet.write(row, 3, new_admission_this_month, total_format)
        sheet.write(row, 4, withdrawals_this_month, total_format)
        sheet.write(row, 5, total_students, total_format)  # Total Strength = Total Students
        sheet.write(row, 6, christian_boys, total_format)
        sheet.write(row, 7, christian_girls, total_format)
        sheet.write(row, 8, christian_total, total_format)
        sheet.write(row, 9, muslim_boys, total_format)
        sheet.write(row, 10, muslim_girls, total_format)
        sheet.write(row, 11, muslim_total, total_format)
        sheet.write(row, 12, total_students, total_format)  # Total Students = Same as Total Strength

    def _write_class_total_row(self, sheet, row, class_name, boys_totals, girls_totals, total_strength, format):
        """Write class-wise total row."""
        sheet.write(row, 0, f"{class_name} Total", format)
        sheet.write(row, 6, boys_totals['Christian'], format)
        sheet.write(row, 7, girls_totals['Christian'], format)
        sheet.write(row, 8, boys_totals['Christian'] + girls_totals['Christian'], format)
        sheet.write(row, 9, boys_totals['Islam'], format)
        sheet.write(row, 10, girls_totals['Islam'], format)
        sheet.write(row, 11, boys_totals['Islam'] + girls_totals['Islam'], format)
        sheet.write(row, 12, total_strength, format)

    def _write_grand_total_row(self, sheet, row, grand_boys_total, grand_girls_total, grand_total_format):
        """Write the final grand total row."""
        sheet.write(row, 0, 'Grand Total', grand_total_format)
        sheet.write(row, 6, grand_boys_total['Christian'], grand_total_format)
        sheet.write(row, 7, grand_girls_total['Christian'], grand_total_format)
        sheet.write(row, 8, grand_boys_total['Christian'] + grand_girls_total['Christian'], grand_total_format)
        sheet.write(row, 9, grand_boys_total['Islam'], grand_total_format)
        sheet.write(row, 10, grand_girls_total['Islam'], grand_total_format)
        sheet.write(row, 11, grand_boys_total['Islam'] + grand_girls_total['Islam'], grand_total_format)
        sheet.write(row, 12, grand_boys_total['Christian'] + grand_girls_total['Christian'] +
                    grand_boys_total['Islam'] + grand_girls_total['Islam'], grand_total_format)