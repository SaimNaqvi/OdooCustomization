from odoo import models, fields
from datetime import datetime


class ReportStudentLedgerXlsx(models.AbstractModel):
    _name = 'report.peb_custom_reports.report_student_ledger_xlsx'
    _inherit = 'report.report_xlsx.abstract'

    def generate_xlsx_report(self, workbook, data, wizard):
        sheet = workbook.add_worksheet('Student Ledger')

        # Define cell formats with thick borders
        bold_centered = workbook.add_format({'bold': True, 'align': 'center', 'border': 1})
        bold_left = workbook.add_format({'bold': True, 'align': 'left', 'border': 1})
        centered = workbook.add_format({'align': 'center', 'border': 1})
        left_alignedes = workbook.add_format({'align': 'left', 'border': 5, 'bold': True, 'font_size': 21})
        left_aligned = workbook.add_format({'align': 'left', 'border': 1})
        date_format = workbook.add_format({'num_format': 'dd/mm/yyyy', 'align': 'center', 'border': 1})
        title_format = workbook.add_format({'bold': True, 'font_size': 19, 'align': 'center', 'border': 6})  # Thick border added here
        currency_format_no_decimals = workbook.add_format({'align': 'center', 'border': 1, 'num_format': '###'})

        # Total formats (left-aligned)
        total_class_format = workbook.add_format({'bold': True, 'align': 'right', 'border': 1, 'bg_color': '#FFEB9C'})
        total_amount_format = workbook.add_format({'bold': True, 'align': 'center', 'border': 1, 'bg_color': '#FFEB9C', 'font_color': '#9C0006'})

        # Get student details
        student_name = wizard.student_name.name
        student_code = wizard.student_code
        branch_names = ', '.join(wizard.branch_ids.mapped('name'))

        # Report title with thick borders for the top three headings
        sheet.merge_range('A1:G1', 'Fee Received', title_format)
        sheet.write('A2', f'Branches: {branch_names}', left_alignedes)
        sheet.write('A3', f'{student_code} - {student_name}', left_alignedes)

        row_idx = 5  # Start row for data
        invoice_records = self.fetch_invoice_records(student_code, wizard)

        if not invoice_records:
            sheet.write(row_idx, 0, 'No records found', left_aligned)
            return

        invoice_records.sort(key=lambda r: (
            r['fee_year'],
            self.class_sort_key(r['current_grade']),
            r['fee_month'],
            r['received_date'] or fields.Date.today()
        ))

        prev_class = None
        prev_year = None
        year_total = 0
        class_total = 0
        yearly_totals = {}

        for record in invoice_records:
            fee_month_name = datetime(2000, record['fee_month'], 1).strftime('%B')
            fee_year = record['fee_year']
            class_name = record['current_grade'].capitalize()

            # If class changes or year changes, write total for the previous class of the year
            if prev_class is not None and (prev_class != class_name or prev_year != fee_year):
                sheet.merge_range(row_idx, 0, row_idx, 5, f'Total for {prev_year}', total_class_format)
                sheet.write(row_idx, 6, round(class_total), total_amount_format)
                row_idx += 1
                class_total = 0  # Reset class total

            # If class changes, write class header
            if prev_class != class_name:
                sheet.merge_range(row_idx, 0, row_idx, 6, f'Class: {class_name}', bold_centered)
                row_idx += 1
                sheet.write_row(row_idx, 0, ['Class', 'Received Date', 'Bill Number', 'Fee Year', 'Month', 'Due Date', 'Total Bill'], bold_centered)
                row_idx += 1
                prev_class = class_name

            # If year changes, write grand total for the previous year
            if prev_year is not None and prev_year != fee_year:
                sheet.merge_range(row_idx, 0, row_idx, 5, f'Grand Total of Year {prev_year}', total_class_format)
                sheet.write(row_idx, 6, round(year_total), total_amount_format)
                row_idx += 2
                year_total = 0  # Reset yearly total

            # Write student fee details with border
            sheet.write(row_idx, 0, class_name, left_aligned)
            sheet.write(row_idx, 1, record['received_date'] or '', date_format)
            sheet.write(row_idx, 2, record['bill_number'], centered)
            sheet.write(row_idx, 3, fee_year, centered)
            sheet.write(row_idx, 4, fee_month_name, centered)
            sheet.write(row_idx, 5, record['due_date'] or '', date_format)
            sheet.write(row_idx, 6, record['total_bill'], currency_format_no_decimals)

            # Update totals
            class_total += record['total_bill']
            year_total += record['total_bill']
            yearly_totals.setdefault(fee_year, 0)
            yearly_totals[fee_year] += record['total_bill']
            prev_year = fee_year
            row_idx += 1

        # Final class-year total before finishing report
        if prev_class is not None:
            sheet.merge_range(row_idx, 0, row_idx, 5, f'Total for {prev_year}', total_class_format)
            sheet.write(row_idx, 6, round(class_total), total_amount_format)
            row_idx += 1

        # Final year total before finishing report
        if prev_year is not None:
            sheet.merge_range(row_idx, 0, row_idx, 5, f'Grand Total of Year {prev_year}', total_class_format)
            sheet.write(row_idx, 6, round(year_total), total_amount_format)
            row_idx += 2

        # Set column widths
        sheet.set_column('A:G', 15)

    def fetch_invoice_records(self, s_code, wizard):
        start_date = wizard.start_date or '2014-01-01'
        end_date = wizard.end_date or fields.Date.today()
        branch_ids = wizard.branch_ids.ids

        domain = [
            ('state', '=', 'posted'),
            ('partner_id.student_code', '=', wizard.student_code),
            ('invoice_date_due', '>=', start_date),
            ('invoice_date_due', '<=', end_date),
        ]

        # Only apply branch filter if user selected branches
        if branch_ids:
            domain.append(('branch_id', 'in', branch_ids))

        invoice_records = self.env['account.move'].sudo().search(domain)
        records = []
        for invoice in invoice_records:
            fee_year = invoice.invoice_date_due.year if invoice.invoice_date_due else ''
            fee_month = invoice.invoice_date_due.month if invoice.invoice_date_due else 1

            records.append({
                'current_grade': invoice.x_studio_grade or 'Unknown',
                'fee_year': fee_year,
                'fee_month': fee_month,
                'bill_number': invoice.name or '',
                'received_date': invoice.ol_payment_date_compute or '',
                'due_date': invoice.invoice_date_due or '',
                'total_bill': invoice.amount_total or 0.0,
            })

        return records

    def class_sort_key(self, class_name):
        predefined_classes = {'Nur': 0, 'Prep': 1}
        class_name = class_name.strip().capitalize()
        if class_name in predefined_classes:
            return predefined_classes[class_name]
        if class_name.isdigit():
            return int(class_name)
        return 100  # For unknown class names
