from odoo import models, fields
from datetime import datetime, timedelta
import calendar


class StudentInvoiceReportXlsx(models.AbstractModel):
    _name = 'report.peb_custom_reports.report_student_invoice_xlsx'
    _inherit = 'report.report_xlsx.abstract'

    def generate_xlsx_report(self, workbook, data, wizard):
        sheet = workbook.add_worksheet('Total Fee Collection')

        # === Formats ===
        header_format = workbook.add_format({
            'bold': True, 'align': 'center', 'valign': 'vcenter',
            'border': 1, 'font_size': 12, 'bg_color': '#D3D3D3'
        })
        merge_format = workbook.add_format({
            'bold': True, 'border': 1, 'align': 'left',
            'valign': 'vcenter', 'font_size': 14,
        })
        right_align_format = workbook.add_format({
            'border': 1, 'valign': 'vcenter', 'align': 'right',
            'font_size': 14, 'bold': True,
        })
        center_align_format = workbook.add_format({
            'border': 1, 'valign': 'vcenter', 'align': 'center',
            'font_size': 14, 'bold': True,
        })
        student_name_format = workbook.add_format({
            'border': 1, 'align': 'left', 'valign': 'vcenter',
            'font_size': 12,
        })
        numeric_format = workbook.add_format({
            'border': 1, 'valign': 'vcenter', 'num_format': '0.00',
            'align': 'right', 'font_size': 12,
        })
        bold_numeric_format = workbook.add_format({
            'bold': True, 'border': 1, 'valign': 'vcenter',
            'align': 'right', 'font_size': 12,
        })
        integer_format = workbook.add_format({
            'border': 1, 'valign': 'vcenter', 'num_format': '0',
            'align': 'right', 'font_size': 12,
        })
        percentage_format = workbook.add_format({
            'border': 1, 'valign': 'vcenter', 'num_format': '0.00',
            'align': 'right', 'font_size': 12,
        })
        bold_integer_format = workbook.add_format({
            'bold': True, 'border': 1, 'valign': 'vcenter',
            'align': 'right', 'font_size': 12, 'num_format': '0'
        })

        # === Wizard inputs ===
        branch_ids = wizard.branch_id.ids
        start_date = wizard.start_date
        end_date = wizard.end_date
        branch_names = ', '.join([branch.name for branch in wizard.branch_id])
        start_date_str = start_date.strftime("%d-%b-%Y")
        end_date_str = end_date.strftime("%d-%b-%Y")

        row = 3
        domain = [
            ('branch_id', 'in', branch_ids),
            ('invoice_date_due', '>=', start_date),
            ('invoice_date_due', '<=', end_date),
            ('state', '=', 'posted'),
        ]
        if wizard.religion:
            domain.append(('partner_id.religion', '=', wizard.religion))
        if wizard.gender:
            domain.append(('partner_id.gender', '=', wizard.gender))
        if wizard.concessions:
            domain.append(('concession_percent', '=', wizard.concessions))
        if wizard.classes:
            class_names = wizard.classes.mapped('name')
            domain.append(('x_studio_grade', 'in', [cls.lower() for cls in class_names]))
        if wizard.active:
            domain.append(('partner_id.current_enroll_status', '=', 'Enrolled'))

        invoices = self.env['account.move'].sudo().search(domain)
        invoices_by_class = {}
        all_fee_types = set()

        for inv in invoices:
            class_name = (inv.x_studio_grade or 'Unknown Class').lower()
            invoices_by_class.setdefault(class_name, []).append(inv)
            for line in inv.invoice_line_ids:
                all_fee_types.add(line.product_id.name)

        dynamic_fee_types = sorted(all_fee_types - {'Tuition Fee'})

        # === CLASS SORTING HELPER ===
        def class_sort_key(class_name):
            class_name = class_name.strip().lower()
            if class_name == 'nur':
                return 0
            elif class_name == 'prep':
                return 1
            try:
                return int(class_name) + 1
            except ValueError:
                return 999

        sorted_class_names = sorted(invoices_by_class.keys(), key=class_sort_key)

        current_date = start_date
        while current_date <= end_date:
            for class_name in sorted_class_names:
                class_invoices = invoices_by_class[class_name]
                class_invoices_for_month = [
                    inv for inv in class_invoices
                    if inv.invoice_date_due.month == current_date.month and
                       inv.invoice_date_due.year == current_date.year
                ]

                if class_invoices_for_month:
                    sheet.merge_range(f'A{row}:R{row}', f"Branch: {branch_names}", merge_format)
                    row += 1
                    sheet.merge_range(
                        f'A{row}:Q{row}',
                        f"Detail of Fee Bills Issued From {start_date_str} to {end_date_str} of Class {class_name.capitalize()}",
                        merge_format
                    )
                    row += 1

                    class_invoices_for_month.sort(key=lambda inv: inv.partner_id.name)

                    headers = ['Sr#', 'Reg#', 'Roll No', 'Student Name', 'Actual Fee', 'Bill No', 'Receive Date',
                               'Tuition Fee', 'Concessions'] + dynamic_fee_types + ['Total']
                    sheet.write_row(f'A{row}', headers, header_format)
                    row += 1

                    class_totals = {ftype: 0 for ftype in ['Tuition Fee'] + dynamic_fee_types}
                    pending_amount = received_amount = pending_students = 0
                    total_students = len(class_invoices_for_month)
                    actual_fee_total = 0

                    for idx, inv in enumerate(class_invoices_for_month, start=1):
                        student = inv.partner_id
                        fee_lines = {line.product_id.name: line.price_subtotal for line in inv.invoice_line_ids}
                        tuition_fee = fee_lines.get('Tuition Fee', 0)
                        actual_fee = inv.actual_fee or 0
                        actual_fee_total += actual_fee
                        total_fee = inv.amount_total or 0
                        concession_percentage = inv.concession_percent or 0.0
                        receive_date = inv.ol_payment_date_compute.strftime(
                            '%d-%B-%Y') if inv.ol_payment_date_compute else ''

                        if inv.ol_payment_date_compute:
                            received_amount += total_fee
                        else:
                            pending_amount += total_fee
                            pending_students += 1

                        sheet.write(row, 0, idx, integer_format)
                        sheet.write(row, 1, student.student_code or '', student_name_format)
                        sheet.write(row, 2, student.roll_no or '', student_name_format)
                        sheet.write(row, 3, student.name or '', student_name_format)
                        sheet.write(row, 4, actual_fee, integer_format)
                        sheet.write(row, 5, inv.name or '', student_name_format)
                        sheet.write(row, 6, receive_date, student_name_format)
                        sheet.write(row, 7, tuition_fee, integer_format)
                        sheet.write(row, 8, concession_percentage, percentage_format)

                        class_totals['Tuition Fee'] += tuition_fee

                        col_idx = 9
                        for fee_type in dynamic_fee_types:
                            val = fee_lines.get(fee_type, 0)
                            sheet.write(row, col_idx, val if val else '', integer_format)
                            class_totals[fee_type] = class_totals.get(fee_type, 0) + val
                            col_idx += 1

                        sheet.write(row, col_idx, total_fee, integer_format)
                        row += 1

                    # === Totals Row ===
                    sheet.write(row, 0, '', student_name_format)
                    sheet.write(row, 1, '', student_name_format)
                    sheet.write(row, 2, '', student_name_format)
                    sheet.write(row, 3, "Total", right_align_format)
                    sheet.write(row, 4, actual_fee_total, bold_integer_format)
                    sheet.write(row, 5, '', student_name_format)
                    sheet.write(row, 6, '', student_name_format)
                    sheet.write(row, 7, class_totals['Tuition Fee'], bold_integer_format)
                    sheet.write(row, 8, '', bold_numeric_format)

                    col_idx = 9
                    for fee_type in dynamic_fee_types:
                        sheet.write(row, col_idx, class_totals[fee_type], bold_numeric_format)
                        col_idx += 1

                    invoice_total = sum(inv.amount_total for inv in class_invoices_for_month)
                    sheet.write(row, col_idx, invoice_total, bold_integer_format)
                    row += 2

                    sheet.merge_range(f'A{row}:R{row}',
                                      f"Summary of class {class_name} , Total student {total_students}, Amount Pending = {pending_amount} , Amount Received = {received_amount}",
                                      center_align_format)
                    row += 2

            current_date = (current_date.replace(day=28) + timedelta(days=4)).replace(day=1)

        # === Grand Totals ===
        sheet.set_column('A:Q', 20)
        grand_total_actual_fee = grand_total_received_amount = grand_total_pending_amount = 0
        grand_total_students = grand_total_pending_students = 0
        grand_totals_by_fee_type = {ftype: 0 for ftype in ['Tuition Fee'] + dynamic_fee_types}

        for class_invs in invoices_by_class.values():
            for inv in class_invs:
                grand_total_students += 1
                grand_total_actual_fee += inv.actual_fee or 0
                if inv.ol_payment_date_compute:
                    grand_total_received_amount += inv.amount_total
                else:
                    grand_total_pending_amount += inv.amount_total
                    grand_total_pending_students += 1
                for line in inv.invoice_line_ids:
                    if line.product_id.name in grand_totals_by_fee_type:
                        grand_totals_by_fee_type[line.product_id.name] += line.price_subtotal

        sheet.write(row, 0, '', student_name_format)
        sheet.write(row, 1, '', student_name_format)
        sheet.write(row, 2, '', student_name_format)
        sheet.write(row, 3, "GRAND TOTAL", right_align_format)
        sheet.write(row, 4, grand_total_actual_fee, bold_numeric_format)
        sheet.write(row, 5, '', student_name_format)
        sheet.write(row, 6, '', student_name_format)
        sheet.write(row, 7, grand_totals_by_fee_type['Tuition Fee'], bold_numeric_format)
        sheet.write(row, 8, '', bold_numeric_format)

        col_idx = 9
        for fee_type in dynamic_fee_types:
            sheet.write(row, col_idx, grand_totals_by_fee_type.get(fee_type, 0), bold_numeric_format)
            col_idx += 1

        grand_total_fee = sum(grand_totals_by_fee_type.values())
        sheet.write(row, col_idx, grand_total_fee, bold_numeric_format)
        row += 2

        grand_summary = f"GRAND TOTAL: {grand_total_students} Students, Amount Pending: {grand_total_pending_amount}, Amount Received: {grand_total_received_amount}"
        sheet.merge_range(f'A{row}:R{row}', grand_summary, center_align_format)

    def format_fee_value(self, value):
        if isinstance(value, float):
            if value.is_integer():
                return int(value)
        return value
